import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import { invokeLLM } from "./_core/llm";
import { transcribeAudio } from "./_core/voiceTranscription";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ==================== Subjects Router ====================
  subjects: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getSubjectsByUserId(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return await db.getSubjectById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          description: z.string().optional(),
          color: z.string().optional(),
          icon: z.string().optional(),
          schedule: z.array(z.object({
            day: z.string(),
            startTime: z.string(),
            endTime: z.string(),
            location: z.string().optional(),
          })).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createSubject({
          userId: ctx.user.id,
          ...input,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).max(255).optional(),
          description: z.string().optional(),
          color: z.string().optional(),
          icon: z.string().optional(),
          schedule: z.array(z.object({
            day: z.string(),
            startTime: z.string(),
            endTime: z.string(),
            location: z.string().optional(),
          })).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateSubject(id, ctx.user.id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteSubject(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ==================== Notes Router ====================
  notes: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getNotesByUserId(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return await db.getNoteById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1).max(500),
          content: z.string(),
          subjectId: z.number().optional(),
          tags: z.array(z.string()).optional(),
          attachments: z.array(z.object({
            url: z.string(),
            fileKey: z.string(),
            filename: z.string(),
            mimeType: z.string(),
            size: z.number(),
          })).optional(),
          isPinned: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createNote({
          userId: ctx.user.id,
          ...input,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().min(1).max(500).optional(),
          content: z.string().optional(),
          subjectId: z.number().optional(),
          tags: z.array(z.string()).optional(),
          attachments: z.array(z.object({
            url: z.string(),
            fileKey: z.string(),
            filename: z.string(),
            mimeType: z.string(),
            size: z.number(),
          })).optional(),
          isPinned: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateNote(id, ctx.user.id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteNote(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ==================== Files Router ====================
  files: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getFilesByUserId(ctx.user.id);
    }),

    upload: protectedProcedure
      .input(
        z.object({
          filename: z.string(),
          fileData: z.string(), // base64
          mimeType: z.string(),
          size: z.number(),
          subjectId: z.number().optional(),
          folder: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // تحويل base64 إلى Buffer
        const buffer = Buffer.from(input.fileData, 'base64');
        
        // إنشاء مفتاح فريد للملف
        const fileKey = `${ctx.user.id}/files/${nanoid()}-${input.filename}`;
        
        // رفع الملف إلى S3
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        
        // حفظ معلومات الملف في قاعدة البيانات
        return await db.createFile({
          userId: ctx.user.id,
          filename: input.filename,
          fileKey,
          url,
          mimeType: input.mimeType,
          size: input.size,
          subjectId: input.subjectId,
          folder: input.folder,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteFile(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ==================== Flashcards Router ====================
  flashcards: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getFlashcardsByUserId(ctx.user.id);
    }),

    dueForReview: protectedProcedure.query(async ({ ctx }) => {
      return await db.getFlashcardsDueForReview(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          front: z.string().min(1),
          back: z.string().min(1),
          subjectId: z.number().optional(),
          difficulty: z.enum(["easy", "medium", "hard"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createFlashcard({
          userId: ctx.user.id,
          ...input,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          front: z.string().min(1).optional(),
          back: z.string().min(1).optional(),
          subjectId: z.number().optional(),
          difficulty: z.enum(["easy", "medium", "hard"]).optional(),
          nextReviewDate: z.date().optional(),
          reviewCount: z.number().optional(),
          correctCount: z.number().optional(),
          lastReviewedAt: z.date().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateFlashcard(id, ctx.user.id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteFlashcard(input.id, ctx.user.id);
        return { success: true };
      }),

    review: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          correct: z.boolean(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const flashcard = await db.getFlashcardsByUserId(ctx.user.id).then(cards => cards.find(c => c.id === input.id));
        if (!flashcard) throw new Error("Flashcard not found");

        const reviewCount = (flashcard.reviewCount || 0) + 1;
        const correctCount = (flashcard.correctCount || 0) + (input.correct ? 1 : 0);
        
        // حساب التاريخ القادم للمراجعة بناءً على الإجابة
        let daysUntilNext = 1;
        if (input.correct) {
          // إذا كانت الإجابة صحيحة، زد الفترة الزمنية
          daysUntilNext = Math.min(reviewCount * 2, 30); // أقصى 30 يوم
        }
        
        const nextReviewDate = new Date();
        nextReviewDate.setDate(nextReviewDate.getDate() + daysUntilNext);

        await db.updateFlashcard(input.id, ctx.user.id, {
          reviewCount,
          correctCount,
          lastReviewedAt: new Date(),
          nextReviewDate,
        });

        return { success: true };
      }),
  }),

  // ==================== Pomodoro Router ====================
  pomodoro: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ ctx, input }) => {
        return await db.getPomodoroSessionsByUserId(ctx.user.id, input?.limit);
      }),

    recent: protectedProcedure.query(async ({ ctx }) => {
      return await db.getPomodoroSessionsByUserId(ctx.user.id, 10);
    }),

    create: protectedProcedure
      .input(
        z.object({
          duration: z.number(),
          type: z.enum(["work", "shortBreak", "longBreak"]),
          subjectId: z.number().optional(),
          startedAt: z.date(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createPomodoroSession({
          userId: ctx.user.id,
          ...input,
        });
      }),

    complete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.updatePomodoroSession(input.id, ctx.user.id, {
          completed: true,
          completedAt: new Date(),
        });
        return { success: true };
      }),
  }),

  // ==================== Events Router ====================
  events: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getEventsByUserId(ctx.user.id);
    }),

    upcoming: protectedProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ ctx, input }) => {
        return await db.getUpcomingEvents(ctx.user.id, input?.limit);
      }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1).max(500),
          description: z.string().optional(),
          type: z.enum(["exam", "assignment", "deadline", "other"]),
          eventDate: z.date(),
          location: z.string().optional(),
          reminderBefore: z.number().optional(),
          subjectId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createEvent({
          userId: ctx.user.id,
          ...input,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().min(1).max(500).optional(),
          description: z.string().optional(),
          type: z.enum(["exam", "assignment", "deadline", "other"]).optional(),
          eventDate: z.date().optional(),
          location: z.string().optional(),
          reminderBefore: z.number().optional(),
          subjectId: z.number().optional(),
          completed: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateEvent(id, ctx.user.id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteEvent(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ==================== Notifications Router ====================
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getNotificationsByUserId(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.markNotificationAsRead(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ==================== AI Solver Router ====================
  solver: router({
    solve: protectedProcedure
      .input(
        z.object({
          problemText: z.string().min(1),
          problemImage: z.string().optional(),
          subjectId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // استخدام LLM لحل المسألة
        const messages: any[] = [
          {
            role: "system",
            content: "أنت معلم رياضيات متخصص في حل المسائل الرياضية والعلمية. قم بحل المسألة خطوة بخطوة بشكل واضح ومفصل. استخدم اللغة العربية في الشرح."
          },
        ];

        if (input.problemImage) {
          messages.push({
            role: "user",
            content: [
              { type: "text", text: `المسألة: ${input.problemText}` },
              { type: "image_url", image_url: { url: input.problemImage } },
            ],
          });
        } else {
          messages.push({
            role: "user",
            content: `المسألة: ${input.problemText}`,
          });
        }

        const response = await invokeLLM({ messages });
        const solutionContent = response.choices[0]?.message?.content;
        const solution = typeof solutionContent === 'string' ? solutionContent : "لم أتمكن من حل المسألة";

        // حفظ المسألة في قاعدة البيانات
        await db.createSolvedProblem({
          userId: ctx.user.id,
          problemText: input.problemText,
          problemImage: input.problemImage,
          solution,
          subjectId: input.subjectId,
        });

        return { solution };
      }),

    history: protectedProcedure.query(async ({ ctx }) => {
      return await db.getSolvedProblemsByUserId(ctx.user.id);
    }),
  }),

  // ==================== Audio Transcription Router ====================
  transcribe: router({
    transcribe: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          audioData: z.string(), // base64
          mimeType: z.string(),
          size: z.number(),
          subjectId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // تحويل base64 إلى Buffer
        const buffer = Buffer.from(input.audioData, 'base64');
        
        // إنشاء مفتاح فريد للملف
        const audioKey = `${ctx.user.id}/audio/${nanoid()}.${input.mimeType.split('/')[1]}`;
        
        // رفع الملف إلى S3
        const { url } = await storagePut(audioKey, buffer, input.mimeType);
        
        // تحويل الصوت إلى نص
        const transcription = await transcribeAudio({
          audioUrl: url,
          language: "ar",
        });

        // التحقق من نجاح التحويل
        if ('error' in transcription) {
          throw new Error(transcription.error);
        }

        // حفظ التسجيل في قاعدة البيانات
        const result = await db.createAudioRecording({
          userId: ctx.user.id,
          title: input.title,
          audioUrl: url,
          audioKey,
          transcription: transcription.text,
          duration: Math.round(input.size / 16000), // تقدير تقريبي
          subjectId: input.subjectId,
        });

        return { transcription: transcription.text, recordingId: result };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getAudioRecordingsByUserId(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          transcription: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await db.updateAudioRecording(input.id, ctx.user.id, {
          transcription: input.transcription,
        });
        return { success: true };
      }),
  }),

  // ==================== AI Chat Router ====================
  chat: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getChatConversationsByUserId(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return await db.getChatConversationById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().optional(),
          message: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // استخدام LLM للرد على الرسالة
        const messages = [
          {
            role: "system" as const,
            content: "أنت مساعد دراسي ذكي متخصص في مساعدة الطلاب في دراستهم. يمكنك الإجابة على الأسئلة، تلخيص المواد، والمساعدة في المراجعة. استخدم اللغة العربية وكن واضحاً ومفيداً."
          },
          {
            role: "user" as const,
            content: input.message,
          },
        ];

        const response = await invokeLLM({ messages });
        const assistantMessage = response.choices[0]?.message?.content || "عذراً، لم أتمكن من معالجة طلبك";

        // حفظ المحادثة
        const conversationMessages: Array<{role: "user" | "assistant"; content: string; timestamp: number}> = [
          { role: "user" as "user" | "assistant", content: input.message as string, timestamp: Date.now() },
          { role: "assistant" as "user" | "assistant", content: assistantMessage as string, timestamp: Date.now() },
        ];

        const result = await db.createChatConversation({
          userId: ctx.user.id,
          title: input.title || input.message.substring(0, 50),
          messages: conversationMessages,
        });

        return { message: assistantMessage, conversationId: result };
      }),

    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          message: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // جلب المحادثة الحالية
        const conversation = await db.getChatConversationById(input.conversationId, ctx.user.id);
        if (!conversation) throw new Error("Conversation not found");

        // إضافة رسالة المستخدم
        const messages = [
          {
            role: "system" as const,
            content: "أنت مساعد دراسي ذكي متخصص في مساعدة الطلاب في دراستهم. يمكنك الإجابة على الأسئلة، تلخيص المواد، والمساعدة في المراجعة. استخدم اللغة العربية وكن واضحاً ومفيداً."
          },
          ...conversation.messages.map(m => ({
            role: m.role,
            content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content),
          })),
          {
            role: "user" as const,
            content: input.message,
          },
        ];

        const response = await invokeLLM({ messages });
        const assistantMessage = response.choices[0]?.message?.content || "عذراً، لم أتمكن من معالجة طلبك";

        // تحديث المحادثة
        const updatedMessages: Array<{role: "user" | "assistant"; content: string; timestamp: number}> = [
          ...conversation.messages.map(m => ({
            role: m.role,
            content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content),
            timestamp: m.timestamp,
          })),
          { role: "user" as "user" | "assistant", content: input.message as string, timestamp: Date.now() },
          { role: "assistant" as "user" | "assistant", content: assistantMessage as string, timestamp: Date.now() },
        ];

        await db.updateChatConversation(input.conversationId, ctx.user.id, {
          messages: updatedMessages,
        });

        return { message: assistantMessage };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteChatConversation(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  search: router({
    all: protectedProcedure
      .input(z.object({
        query: z.string(),
        subjectId: z.number().optional(),
        type: z.enum(["all", "notes", "flashcards", "files", "problems"]).optional(),
      }))
      .query(async ({ ctx, input }) => {
        const results = {
          notes: [] as any[],
          flashcards: [] as any[],
          files: [] as any[],
          problems: [] as any[],
        };

        // البحث في الملاحظات
        if (!input.type || input.type === "all" || input.type === "notes") {
          let notesQuery = db.getNotesByUserId(ctx.user.id);
          results.notes = (await notesQuery).filter(note => {
            const matchesQuery = note.title.toLowerCase().includes(input.query.toLowerCase()) ||
                                note.content.toLowerCase().includes(input.query.toLowerCase());
            const matchesSubject = !input.subjectId || note.subjectId === input.subjectId;
            return matchesQuery && matchesSubject;
          });
        }

        // البحث في البطاقات التعليمية
        if (!input.type || input.type === "all" || input.type === "flashcards") {
          let flashcardsQuery = db.getFlashcardsByUserId(ctx.user.id);
          results.flashcards = (await flashcardsQuery).filter(card => {
            const matchesQuery = card.front.toLowerCase().includes(input.query.toLowerCase()) ||
                                card.back.toLowerCase().includes(input.query.toLowerCase());
            const matchesSubject = !input.subjectId || card.subjectId === input.subjectId;
            return matchesQuery && matchesSubject;
          });
        }

        // البحث في الملفات
        if (!input.type || input.type === "all" || input.type === "files") {
          let filesQuery = db.getFilesByUserId(ctx.user.id);
          results.files = (await filesQuery).filter(file => {
            const matchesQuery = file.filename.toLowerCase().includes(input.query.toLowerCase());
            const matchesSubject = !input.subjectId || file.subjectId === input.subjectId;
            return matchesQuery && matchesSubject;
          });
        }

        // البحث في المسائل المحلولة
        if (!input.type || input.type === "all" || input.type === "problems") {
          let problemsQuery = db.getSolvedProblemsByUserId(ctx.user.id);
          results.problems = (await problemsQuery).filter(problem => {
            const matchesQuery = problem.problemText.toLowerCase().includes(input.query.toLowerCase()) ||
                                problem.solution.toLowerCase().includes(input.query.toLowerCase());
            const matchesSubject = !input.subjectId || problem.subjectId === input.subjectId;
            return matchesQuery && matchesSubject;
          });
        }

        return results;
      }),
  }),

  // ==================== Settings Router ====================
  settings: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      let settings = await db.getUserSettings(ctx.user.id);
      if (!settings) {
        await db.initializeUserSettings(ctx.user.id);
        settings = await db.getUserSettings(ctx.user.id);
      }
      return settings;
    }),

    update: protectedProcedure
      .input(
        z.object({
          language: z.string().optional(),
          category: z.enum(["school", "university"]).optional(),
          plan: z.enum(["free", "premium", "trial"]).optional(),
          isOnboardingComplete: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await db.updateUserSettings(ctx.user.id, input);
        return { success: true };
      }),

    checkTrialStatus: protectedProcedure.query(async ({ ctx }) => {
      const settings = await db.getUserSettings(ctx.user.id);
      if (!settings) return { isTrialActive: false, daysRemaining: 0 };

      if (settings.plan !== "trial" || !settings.trialEndDate) {
        return { isTrialActive: false, daysRemaining: 0 };
      }

      const now = new Date();
      const endDate = new Date(settings.trialEndDate);
      const daysRemaining = Math.ceil(
        (endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (daysRemaining <= 0) {
        // انتهت التجربة، تحويل إلى free
        await db.updateUserSettings(ctx.user.id, { plan: "free" });
        return { isTrialActive: false, daysRemaining: 0 };
      }

      return { isTrialActive: true, daysRemaining };
    }),

    getUsageStats: protectedProcedure
      .input(z.object({ feature: z.string() }))
      .query(async ({ ctx, input }) => {
        const todayCount = await db.getFeatureUsageToday(ctx.user.id, input.feature);
        const monthStats = await db.getFeatureUsageStats(ctx.user.id, input.feature, 30);
        return { todayCount, monthStats };
      }),

    trackUsage: protectedProcedure
      .input(z.object({ feature: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await db.trackFeatureUsage(ctx.user.id, input.feature);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
