import { eq, desc, and, gte, lte, isNull, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  subjects,
  notes,
  flashcards,
  pomodoroSessions,
  files,
  events,
  notifications,
  solvedProblems,
  audioRecordings,
  chatConversations,
  type Subject,
  type InsertSubject,
  type Note,
  type InsertNote,
  type Flashcard,
  type InsertFlashcard,
  type PomodoroSession,
  type InsertPomodoroSession,
  type File,
  type InsertFile,
  type Event,
  type InsertEvent,
  type Notification,
  type InsertNotification,
  type SolvedProblem,
  type InsertSolvedProblem,
  type AudioRecording,
  type InsertAudioRecording,
  type ChatConversation,
  type InsertChatConversation,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== User Functions ====================
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ==================== Subject Functions ====================
export async function createSubject(subject: InsertSubject) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create subject: database not available");
    return { insertId: Date.now() };
  }
  
  const result = await db.insert(subjects).values(subject);
  return result;
}

export async function getSubjectsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(subjects).where(eq(subjects.userId, userId)).orderBy(desc(subjects.createdAt));
}

export async function getSubjectById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(subjects).where(and(eq(subjects.id, id), eq(subjects.userId, userId))).limit(1);
  return result[0];
}

export async function updateSubject(id: number, userId: number, data: Partial<InsertSubject>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(subjects).set(data).where(and(eq(subjects.id, id), eq(subjects.userId, userId)));
}

export async function deleteSubject(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(subjects).where(and(eq(subjects.id, id), eq(subjects.userId, userId)));
}

// ==================== Note Functions ====================
export async function createNote(note: InsertNote) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create note: database not available");
    return { insertId: Date.now() };
  }
  
  const result = await db.insert(notes).values(note);
  return result;
}

export async function getNotesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(notes).where(eq(notes.userId, userId)).orderBy(desc(notes.isPinned), desc(notes.updatedAt));
}

export async function getNoteById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(notes).where(and(eq(notes.id, id), eq(notes.userId, userId))).limit(1);
  return result[0];
}

export async function updateNote(id: number, userId: number, data: Partial<InsertNote>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(notes).set(data).where(and(eq(notes.id, id), eq(notes.userId, userId)));
}

export async function deleteNote(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(notes).where(and(eq(notes.id, id), eq(notes.userId, userId)));
}

// ==================== Flashcard Functions ====================
export async function createFlashcard(flashcard: InsertFlashcard) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create flashcard: database not available");
    return { insertId: Date.now() };
  }
  
  const result = await db.insert(flashcards).values(flashcard);
  return result;
}

export async function getFlashcardsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(flashcards).where(eq(flashcards.userId, userId)).orderBy(desc(flashcards.createdAt));
}

export async function getFlashcardsDueForReview(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  return await db.select().from(flashcards).where(
    and(
      eq(flashcards.userId, userId),
      or(
        lte(flashcards.nextReviewDate, now),
        isNull(flashcards.nextReviewDate)
      )
    )
  );
}

export async function updateFlashcard(id: number, userId: number, data: Partial<InsertFlashcard>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(flashcards).set(data).where(and(eq(flashcards.id, id), eq(flashcards.userId, userId)));
}

export async function deleteFlashcard(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(flashcards).where(and(eq(flashcards.id, id), eq(flashcards.userId, userId)));
}

// ==================== Pomodoro Functions ====================
export async function createPomodoroSession(session: InsertPomodoroSession) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(pomodoroSessions).values(session);
  return result;
}

export async function getPomodoroSessionsByUserId(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(pomodoroSessions).where(eq(pomodoroSessions.userId, userId)).orderBy(desc(pomodoroSessions.startedAt)).limit(limit);
}

export async function updatePomodoroSession(id: number, userId: number, data: Partial<InsertPomodoroSession>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(pomodoroSessions).set(data).where(and(eq(pomodoroSessions.id, id), eq(pomodoroSessions.userId, userId)));
}

// ==================== File Functions ====================
export async function createFile(file: InsertFile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(files).values(file);
  return result;
}

export async function getFilesByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(files).where(eq(files.userId, userId)).orderBy(desc(files.createdAt));
}

export async function deleteFile(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(files).where(and(eq(files.id, id), eq(files.userId, userId)));
}

// ==================== Event Functions ====================
export async function createEvent(event: InsertEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(events).values(event);
  return result;
}

export async function getEventsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(events).where(eq(events.userId, userId)).orderBy(events.eventDate);
}

export async function getUpcomingEvents(userId: number, limit: number = 10) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  return await db.select().from(events).where(
    and(
      eq(events.userId, userId),
      gte(events.eventDate, now)
    )
  ).orderBy(events.eventDate).limit(limit);
}

export async function updateEvent(id: number, userId: number, data: Partial<InsertEvent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(events).set(data).where(and(eq(events.id, id), eq(events.userId, userId)));
}

export async function deleteEvent(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(events).where(and(eq(events.id, id), eq(events.userId, userId)));
}

// ==================== Notification Functions ====================
export async function createNotification(notification: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(notifications).values(notification);
  return result;
}

export async function getNotificationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(notifications).set({ isRead: true }).where(and(eq(notifications.id, id), eq(notifications.userId, userId)));
}

// ==================== Solved Problem Functions ====================
export async function createSolvedProblem(problem: InsertSolvedProblem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(solvedProblems).values(problem);
  return result;
}

export async function getSolvedProblemsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(solvedProblems).where(eq(solvedProblems.userId, userId)).orderBy(desc(solvedProblems.createdAt));
}

// ==================== Audio Recording Functions ====================
export async function createAudioRecording(recording: InsertAudioRecording) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(audioRecordings).values(recording);
  return result;
}

export async function getAudioRecordingsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(audioRecordings).where(eq(audioRecordings.userId, userId)).orderBy(desc(audioRecordings.createdAt));
}

export async function updateAudioRecording(id: number, userId: number, data: Partial<InsertAudioRecording>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(audioRecordings).set(data).where(and(eq(audioRecordings.id, id), eq(audioRecordings.userId, userId)));
}

// ==================== Chat Conversation Functions ====================
export async function createChatConversation(conversation: InsertChatConversation) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create chat conversation: database not available");
    return { insertId: Date.now() };
  }
  
  const result = await db.insert(chatConversations).values(conversation);
  return result;
}

export async function getChatConversationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(chatConversations).where(eq(chatConversations.userId, userId)).orderBy(desc(chatConversations.updatedAt));
}

export async function getChatConversationById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(chatConversations).where(and(eq(chatConversations.id, id), eq(chatConversations.userId, userId))).limit(1);
  return result[0];
}

export async function updateChatConversation(id: number, userId: number, data: Partial<InsertChatConversation>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(chatConversations).set(data).where(and(eq(chatConversations.id, id), eq(chatConversations.userId, userId)));
}

export async function deleteChatConversation(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(chatConversations).where(and(eq(chatConversations.id, id), eq(chatConversations.userId, userId)));
}


// ==================== User Settings Functions ====================
import { userSettings, chatSources, featureUsage, type UserSettings, type InsertUserSettings, type ChatSource, type InsertChatSource, type FeatureUsage, type InsertFeatureUsage } from "../drizzle/schema";

export async function getUserSettings(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1);
  return result[0];
}

export async function createUserSettings(settings: InsertUserSettings) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(userSettings).values(settings);
  return result;
}

export async function updateUserSettings(userId: number, data: Partial<InsertUserSettings>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(userSettings).set(data).where(eq(userSettings.userId, userId));
}

export async function initializeUserSettings(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getUserSettings(userId);
  if (!existing) {
    await createUserSettings({
      userId,
      language: "ar",
      category: "school",
      plan: "free",
      isOnboardingComplete: false,
    });
  }
}

// ==================== Chat Sources Functions ====================
export async function createChatSource(source: InsertChatSource) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(chatSources).values(source);
  return result;
}

export async function getChatSourcesByConversationId(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(chatSources).where(eq(chatSources.conversationId, conversationId)).orderBy(desc(chatSources.createdAt));
}

export async function deleteChatSource(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(chatSources).where(eq(chatSources.id, id));
}

// ==================== Feature Usage Functions ====================
export async function trackFeatureUsage(userId: number, feature: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const existing = await db.select().from(featureUsage).where(
    and(
      eq(featureUsage.userId, userId),
      eq(featureUsage.feature, feature),
      eq(featureUsage.usageDate, today)
    )
  ).limit(1);
  
  if (existing.length > 0) {
    await db.update(featureUsage).set({
      count: (existing[0].count || 0) + 1,
    }).where(eq(featureUsage.id, existing[0].id));
  } else {
    await db.insert(featureUsage).values({
      userId,
      feature,
      usageDate: today,
      count: 1,
    });
  }
}

export async function getFeatureUsageToday(userId: number, feature: string) {
  const db = await getDb();
  if (!db) return 0;
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const result = await db.select().from(featureUsage).where(
    and(
      eq(featureUsage.userId, userId),
      eq(featureUsage.feature, feature),
      eq(featureUsage.usageDate, today)
    )
  ).limit(1);
  
  return result.length > 0 ? result[0].count : 0;
}

export async function getFeatureUsageStats(userId: number, feature: string, days: number = 30) {
  const db = await getDb();
  if (!db) return [];
  
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  startDate.setHours(0, 0, 0, 0);
  
  return await db.select().from(featureUsage).where(
    and(
      eq(featureUsage.userId, userId),
      eq(featureUsage.feature, feature),
      gte(featureUsage.usageDate, startDate)
    )
  ).orderBy(desc(featureUsage.usageDate));
}
