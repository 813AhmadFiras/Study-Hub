import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, float, json, date } from "drizzle-orm/mysql-core";

/**
 * جداول قاعدة البيانات لمنصة Study Hub
 */

// جدول المستخدمين
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// جدول المواد الدراسية
export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  color: varchar("color", { length: 7 }).default("#3b82f6"), // لون المادة
  icon: varchar("icon", { length: 50 }), // أيقونة المادة
  schedule: json("schedule").$type<{
    day: string;
    startTime: string;
    endTime: string;
    location?: string;
  }[]>(), // الجدول الزمني
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

// جدول الملاحظات
export const notes = mysqlTable("notes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري - يمكن ربط الملاحظة بمادة
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(), // محتوى HTML من المحرر الغني
  tags: json("tags").$type<string[]>(), // وسوم للبحث
  attachments: json("attachments").$type<{
    url: string;
    fileKey: string;
    filename: string;
    mimeType: string;
    size: number;
  }[]>(), // المرفقات
  isPinned: boolean("isPinned").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Note = typeof notes.$inferSelect;
export type InsertNote = typeof notes.$inferInsert;

// جدول البطاقات التعليمية
export const flashcards = mysqlTable("flashcards", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري
  front: text("front").notNull(), // الوجه الأمامي
  back: text("back").notNull(), // الوجه الخلفي
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium"),
  nextReviewDate: timestamp("nextReviewDate"), // تاريخ المراجعة القادمة
  reviewCount: int("reviewCount").default(0), // عدد المراجعات
  correctCount: int("correctCount").default(0), // عدد الإجابات الصحيحة
  lastReviewedAt: timestamp("lastReviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Flashcard = typeof flashcards.$inferSelect;
export type InsertFlashcard = typeof flashcards.$inferInsert;

// جدول جلسات بومودورو
export const pomodoroSessions = mysqlTable("pomodoroSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري
  duration: int("duration").notNull(), // المدة بالدقائق
  type: mysqlEnum("type", ["work", "shortBreak", "longBreak"]).notNull(),
  completed: boolean("completed").default(false),
  startedAt: timestamp("startedAt").notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PomodoroSession = typeof pomodoroSessions.$inferSelect;
export type InsertPomodoroSession = typeof pomodoroSessions.$inferInsert;

// جدول الملفات
export const files = mysqlTable("files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري
  filename: varchar("filename", { length: 500 }).notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(), // مفتاح S3
  url: text("url").notNull(), // رابط الملف في S3
  mimeType: varchar("mimeType", { length: 100 }).notNull(),
  size: int("size").notNull(), // الحجم بالبايتات
  folder: varchar("folder", { length: 255 }), // المجلد
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;

// جدول الأحداث (التقويم)
export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["exam", "assignment", "deadline", "other"]).notNull(),
  eventDate: timestamp("eventDate").notNull(), // تاريخ ووقت الحدث
  location: varchar("location", { length: 255 }),
  reminderBefore: int("reminderBefore"), // التذكير قبل X دقيقة
  completed: boolean("completed").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;

// جدول الإشعارات
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content"),
  type: mysqlEnum("type", ["event", "reminder", "achievement", "system"]).notNull(),
  isRead: boolean("isRead").default(false),
  relatedId: int("relatedId"), // معرف العنصر المرتبط (مثل حدث أو مهمة)
  relatedType: varchar("relatedType", { length: 50 }), // نوع العنصر المرتبط
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// جدول المسائل المحلولة
export const solvedProblems = mysqlTable("solvedProblems", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري
  problemText: text("problemText").notNull(), // نص المسألة
  problemImage: text("problemImage"), // رابط صورة المسألة إن وجدت
  solution: text("solution").notNull(), // الحل خطوة بخطوة
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SolvedProblem = typeof solvedProblems.$inferSelect;
export type InsertSolvedProblem = typeof solvedProblems.$inferInsert;

// جدول التسجيلات الصوتية
export const audioRecordings = mysqlTable("audioRecordings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  subjectId: int("subjectId"), // اختياري
  title: varchar("title", { length: 500 }).notNull(),
  audioUrl: text("audioUrl").notNull(), // رابط الملف الصوتي في S3
  audioKey: varchar("audioKey", { length: 500 }).notNull(),
  transcription: text("transcription"), // النص المحول
  duration: int("duration"), // المدة بالثواني
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AudioRecording = typeof audioRecordings.$inferSelect;
export type InsertAudioRecording = typeof audioRecordings.$inferInsert;

// جدول المحادثات مع المساعد الذكي
export const chatConversations = mysqlTable("chatConversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 500 }), // عنوان المحادثة
  messages: json("messages").$type<{
    role: "user" | "assistant";
    content: string;
    timestamp: number;
  }[]>().notNull(), // رسائل المحادثة
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatConversation = typeof chatConversations.$inferSelect;
export type InsertChatConversation = typeof chatConversations.$inferInsert;

// جدول إعدادات المستخدم والخطة
export const userSettings = mysqlTable("userSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  language: varchar("language", { length: 10 }).default("ar").notNull(), // ar, en, fr, etc.
  category: mysqlEnum("category", ["school", "university"]).default("school").notNull(), // فئة الطالب
  plan: mysqlEnum("plan", ["free", "premium", "trial"]).default("free").notNull(), // الخطة الحالية
  trialStartDate: timestamp("trialStartDate"), // تاريخ بدء التجربة المجانية
  trialEndDate: timestamp("trialEndDate"), // تاريخ انتهاء التجربة المجانية
  premiumStartDate: timestamp("premiumStartDate"), // تاريخ بدء الاشتراك المدفوع
  premiumEndDate: timestamp("premiumEndDate"), // تاريخ انتهاء الاشتراك المدفوع
  isOnboardingComplete: boolean("isOnboardingComplete").default(false), // هل أكمل الـ Onboarding
  dailyMessageCount: int("dailyMessageCount").default(0), // عدد الرسائل اليومية
  dailyFileUploadCount: int("dailyFileUploadCount").default(0), // عدد الملفات المرفوعة يومياً
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = typeof userSettings.$inferInsert;

// جدول مصادر المحادثة (ملفات، نصوص، سياق)
export const chatSources = mysqlTable("chatSources", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  conversationId: int("conversationId").notNull(), // المحادثة المرتبطة
  sourceType: mysqlEnum("sourceType", ["file", "text", "note", "flashcard"]).notNull(), // نوع المصدر
  sourceId: int("sourceId"), // معرف المصدر (مثل معرف الملف أو الملاحظة)
  content: text("content"), // محتوى النص المباشر
  filename: varchar("filename", { length: 500 }), // اسم الملف
  url: text("url"), // رابط الملف
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatSource = typeof chatSources.$inferSelect;
export type InsertChatSource = typeof chatSources.$inferInsert;

// جدول استخدام الميزات (لتتبع الحدود)
export const featureUsage = mysqlTable("featureUsage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  feature: varchar("feature", { length: 50 }).notNull(), // اسم الميزة (aiChat, fileUpload, etc.)
  usageDate: date("usageDate").notNull(), // التاريخ
  count: int("count").default(1).notNull(), // عدد الاستخدامات
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FeatureUsage = typeof featureUsage.$inferSelect;
export type InsertFeatureUsage = typeof featureUsage.$inferInsert;
