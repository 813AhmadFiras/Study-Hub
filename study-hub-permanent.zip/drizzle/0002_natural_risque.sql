CREATE TABLE `chatSources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`conversationId` int NOT NULL,
	`sourceType` enum('file','text','note','flashcard') NOT NULL,
	`sourceId` int,
	`content` text,
	`filename` varchar(500),
	`url` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatSources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `featureUsage` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`feature` varchar(50) NOT NULL,
	`usageDate` date NOT NULL,
	`count` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `featureUsage_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`language` varchar(10) NOT NULL DEFAULT 'ar',
	`category` enum('school','university') NOT NULL DEFAULT 'school',
	`plan` enum('free','premium','trial') NOT NULL DEFAULT 'free',
	`trialStartDate` timestamp,
	`trialEndDate` timestamp,
	`premiumStartDate` timestamp,
	`premiumEndDate` timestamp,
	`isOnboardingComplete` boolean DEFAULT false,
	`dailyMessageCount` int DEFAULT 0,
	`dailyFileUploadCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `userSettings_userId_unique` UNIQUE(`userId`)
);
