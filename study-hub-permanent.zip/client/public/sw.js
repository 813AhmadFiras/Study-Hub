// Service Worker for Study Hub PWA
const CACHE_NAME = 'study-hub-v1';
const RUNTIME_CACHE = 'study-hub-runtime-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192x192.png',
  '/icon-512x512.png',
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Caching static assets');
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('[Service Worker] Failed to cache some assets:', err);
        // Continue even if some assets fail to cache
        return Promise.resolve();
      });
    })
  );
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE) {
            console.log('[Service Worker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch event - network first, fall back to cache
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // Skip API calls (let them go through network)
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Cache successful API responses
          if (response.status === 200) {
            const cache = caches.open(RUNTIME_CACHE);
            cache.then((c) => c.put(request, response.clone()));
          }
          return response;
        })
        .catch(() => {
          // Return cached API response if offline
          return caches.match(request).then((cached) => {
            if (cached) {
              console.log('[Service Worker] Returning cached API response');
              return cached;
            }
            // Return offline response
            return new Response(
              JSON.stringify({
                error: 'Offline - cached data may be unavailable',
              }),
              {
                status: 503,
                statusText: 'Service Unavailable',
                headers: new Headers({
                  'Content-Type': 'application/json',
                }),
              }
            );
          });
        })
    );
    return;
  }

  // For HTML and other assets, use network-first strategy
  event.respondWith(
    fetch(request)
      .then((response) => {
        // Cache successful responses
        if (response.status === 200) {
          const cache = caches.open(RUNTIME_CACHE);
          cache.then((c) => c.put(request, response.clone()));
        }
        return response;
      })
      .catch(() => {
        // Fall back to cache
        return caches.match(request).then((cached) => {
          if (cached) {
            console.log('[Service Worker] Returning cached response:', url.pathname);
            return cached;
          }

          // Return offline page for navigation requests
          if (request.mode === 'navigate') {
            return caches.match('/index.html').then((cached) => {
              if (cached) {
                return cached;
              }
              return new Response(
                '<!DOCTYPE html><html><body><h1>Offline</h1><p>You are offline. Please check your connection.</p></body></html>',
                {
                  headers: { 'Content-Type': 'text/html' },
                }
              );
            });
          }

          // Return a generic offline response
          return new Response('Offline', {
            status: 503,
            statusText: 'Service Unavailable',
          });
        });
      })
  );
});

// Handle messages from clients
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data && event.data.type === 'CLEAR_CACHE') {
    caches.delete(RUNTIME_CACHE).then(() => {
      console.log('[Service Worker] Runtime cache cleared');
    });
  }
});

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-notes') {
    event.waitUntil(syncNotes());
  }
  if (event.tag === 'sync-flashcards') {
    event.waitUntil(syncFlashcards());
  }
});

async function syncNotes() {
  try {
    const response = await fetch('/api/trpc/notes.sync', {
      method: 'POST',
    });
    return response.ok;
  } catch (error) {
    console.error('[Service Worker] Failed to sync notes:', error);
    return false;
  }
}

async function syncFlashcards() {
  try {
    const response = await fetch('/api/trpc/flashcards.sync', {
      method: 'POST',
    });
    return response.ok;
  } catch (error) {
    console.error('[Service Worker] Failed to sync flashcards:', error);
    return false;
  }
}

console.log('[Service Worker] Loaded successfully');
