import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MessageSquare, X, Minus, Maximize2 } from "lucide-react";
import { AIChatBox, Message } from "./AIChatBox";
import { trpc } from "@/lib/trpc";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function FloatingChat() {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: t('nav.chat') + ": كيف يمكنني مساعدتك اليوم؟" }
  ]);
  const [conversationId, setConversationId] = useState<number | null>(null);

  const chatMutation = trpc.chat.send.useMutation({
    onSuccess: (data: any) => {
      const content = typeof data.message === 'string' ? data.message : JSON.stringify(data.message);
      setMessages(prev => [...prev, { role: "assistant", content }]);
    }
  });

  const createChatMutation = trpc.chat.create.useMutation({
    onSuccess: (data: any) => {
      const id = data.conversationId?.insertId || data.conversationId || data.id;
      setConversationId(id);
      const content = typeof data.message === 'string' ? data.message : JSON.stringify(data.message);
      setMessages(prev => [...prev, { role: "assistant", content }]);
    }
  });

  const handleSendMessage = (content: string) => {
    setMessages(prev => [...prev, { role: "user", content }]);
    
    if (conversationId) {
      chatMutation.mutate({ conversationId, message: content });
    } else {
      createChatMutation.mutate({ message: content });
    }
  };

  return (
    <div className="fixed bottom-6 left-6 z-50 flex flex-col items-end">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? "60px" : "500px"
            }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className={cn(
              "mb-4 w-[350px] sm:w-[400px] bg-card border shadow-2xl rounded-xl overflow-hidden flex flex-col transition-all duration-300",
              isMinimized ? "h-[60px]" : "h-[500px]"
            )}
          >
            {/* Header */}
            <div className="p-4 border-b bg-primary text-primary-foreground flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                <span className="font-bold">{t('nav.chat')}</span>
              </div>
              <div className="flex items-center gap-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/10"
                  onClick={() => setIsMinimized(!isMinimized)}
                >
                  {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-primary-foreground hover:bg-primary-foreground/10"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Chat Content */}
            {!isMinimized && (
              <div className="flex-1 overflow-hidden">
                <AIChatBox
                  messages={messages}
                  onSendMessage={handleSendMessage}
                  isLoading={chatMutation.isPending || createChatMutation.isPending}
                  height="100%"
                  className="border-0 rounded-none"
                  placeholder={t('nav.chat') + "..."}
                  emptyStateMessage="ابدأ المحادثة مع المساعد الذكي"
                />
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <Button
        size="lg"
        className={cn(
          "h-14 w-14 rounded-full shadow-xl bg-primary hover:bg-primary/90 text-primary-foreground transition-transform hover:scale-110",
          isOpen && "scale-0 opacity-0"
        )}
        onClick={() => setIsOpen(true)}
      >
        <MessageSquare className="h-6 w-6" />
      </Button>
    </div>
  );
}
