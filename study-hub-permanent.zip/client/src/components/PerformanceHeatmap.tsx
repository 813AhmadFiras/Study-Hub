import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface HeatmapData {
  day: string;
  hours: number[];
}

export function PerformanceHeatmap() {
  const data: HeatmapData[] = [
    { day: "الاثنين", hours: [2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5] },
    { day: "الثلاثاء", hours: [1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6, 5, 4, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6] },
    { day: "الأربعاء", hours: [3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4] },
    { day: "الخميس", hours: [4, 5, 6, 7, 8, 9, 8, 7, 6, 5, 4, 3, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6, 5] },
    { day: "الجمعة", hours: [1, 1, 2, 2, 3, 3, 2, 2, 1, 1, 0, 0, 1, 1, 2, 2, 3, 3, 2, 2, 1, 1, 0, 0] },
    { day: "السبت", hours: [5, 6, 7, 8, 9, 9, 8, 7, 6, 5, 4, 3, 2, 3, 4, 5, 6, 7, 8, 9, 9, 8, 7, 6] },
    { day: "الأحد", hours: [3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3, 2, 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4] },
  ];

  const getColor = (value: number) => {
    if (value === 0) return "bg-slate-700";
    if (value <= 2) return "bg-blue-900";
    if (value <= 4) return "bg-blue-700";
    if (value <= 6) return "bg-blue-500";
    if (value <= 8) return "bg-blue-400";
    return "bg-blue-300";
  };

  const hours = Array.from({ length: 24 }, (_, i) => `${i}:00`);

  return (
    <Card>
      <CardHeader>
        <CardTitle>خريطة الأداء الحرارية</CardTitle>
        <CardDescription>مستوى التركيز والإنتاجية حسب الساعة والأيام</CardDescription>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <div className="space-y-2">
          {/* Hours Header */}
          <div className="flex gap-1">
            <div className="w-16 flex-shrink-0" />
            <div className="flex gap-1">
              {hours.map((hour, index) => (
                <div
                  key={hour}
                  className="w-8 h-6 flex items-center justify-center text-xs text-muted-foreground"
                >
                  {index % 4 === 0 ? hour : ""}
                </div>
              ))}
            </div>
          </div>

          {/* Heatmap Grid */}
          {data.map((row) => (
            <div key={row.day} className="flex gap-1 items-center">
              <div className="w-16 flex-shrink-0 text-sm font-medium">{row.day}</div>
              <div className="flex gap-1">
                {row.hours.map((value, index) => (
                  <div
                    key={index}
                    className={`w-8 h-8 rounded-sm ${getColor(value)} hover:ring-2 hover:ring-primary transition-all cursor-pointer`}
                    title={`${row.day} - ${index}:00 - مستوى: ${value}`}
                  />
                ))}
              </div>
            </div>
          ))}

          {/* Legend */}
          <div className="mt-6 flex items-center gap-4 text-xs">
            <span className="text-muted-foreground">أقل</span>
            <div className="flex gap-1">
              {[0, 2, 4, 6, 8, 9].map((value) => (
                <div
                  key={value}
                  className={`w-4 h-4 rounded ${getColor(value)}`}
                  title={`مستوى ${value}`}
                />
              ))}
            </div>
            <span className="text-muted-foreground">أكثر</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
