import { Button } from "@/components/ui/button";
import { Moon, Sun, Languages, Monitor } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useTheme } from "@/contexts/ThemeContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Navbar() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { t, i18n } = useTranslation();
  const { theme, setTheme, resolvedTheme } = useTheme();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'ar' ? 'en' : 'ar';
    i18n.changeLanguage(newLang);
  };

  const handleLogoClick = () => {
    setLocation("/");
  };

  const handleGetStarted = () => {
    if (isAuthenticated) {
      setLocation("/");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-slate-950 to-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <button
            onClick={handleLogoClick}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">📚</span>
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              StudyHub
            </span>
          </button>

          {/* Center Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-slate-300 hover:text-white transition-colors">
              {i18n.language === 'ar' ? 'الرئيسية' : 'Home'}
            </a>
            <a href="#features" className="text-slate-300 hover:text-white transition-colors">
              {i18n.language === 'ar' ? 'الميزات' : 'Features'}
            </a>
            <a href="#about" className="text-slate-300 hover:text-white transition-colors">
              {i18n.language === 'ar' ? 'من نحن' : 'About'}
            </a>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white">
                  {resolvedTheme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setTheme('light')}>
                  <Sun className="mr-2 h-4 w-4" /> {t('settings.light')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme('dark')}>
                  <Moon className="mr-2 h-4 w-4" /> {t('settings.dark')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTheme('system')}>
                  <Monitor className="mr-2 h-4 w-4" /> {t('settings.system')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <button 
              onClick={toggleLanguage}
              className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white flex items-center gap-1"
            >
              <Languages className="w-5 h-5" />
              <span className="text-xs font-bold uppercase">{i18n.language}</span>
            </button>

            {isAuthenticated ? (
              <div className="flex items-center gap-4">
                <span className="text-sm text-slate-400 hidden sm:inline">
                  {t('common.welcome')}، {user?.name}
                </span>
                <Button
                  onClick={() => setLocation("/")}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                >
                  {t('nav.dashboard')}
                </Button>
              </div>
            ) : (
              <>
                <Button
                  variant="ghost"
                  onClick={() => setLocation("/login")}
                  className="text-slate-300 hover:text-white hover:bg-slate-800"
                >
                  {i18n.language === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
                </Button>
                <Button
                  onClick={handleGetStarted}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                >
                  {i18n.language === 'ar' ? 'ابدأ الآن' : 'Get Started'}
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
