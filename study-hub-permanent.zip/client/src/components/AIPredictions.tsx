import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, TrendingUp, AlertCircle, Lightbulb, Target } from "lucide-react";

interface Prediction {
  id: string;
  type: "trend" | "alert" | "opportunity";
  title: string;
  description: string;
  confidence: number;
  action?: string;
}

export function AIPredictions() {
  const predictions: Prediction[] = [
    {
      id: "1",
      type: "trend",
      title: "📈 توقع تحسن الأداء",
      description: "بناءً على نمط دراستك، سيتحسن أداؤك في الرياضيات بنسبة 8-12% خلال الأسبوع القادم",
      confidence: 92,
      action: "عرض الخطة الموصى بها",
    },
    {
      id: "2",
      type: "alert",
      title: "⚠️ تحذير من انخفاض الإنتاجية",
      description: "لاحظنا انخفاضاً بنسبة 15% في إنتاجيتك مقارنة بالأسبوع الماضي. قد يكون السبب قلة ساعات النوم.",
      confidence: 85,
      action: "عرض نصائح الصحة",
    },
    {
      id: "3",
      type: "opportunity",
      title: "💡 فرصة للتحسن السريع",
      description: "لديك فرصة ذهبية لإتقان مادة اللغة الإنجليزية إذا ركزت عليها 3 ساعات يومياً لمدة أسبوعين",
      confidence: 88,
      action: "إنشاء خطة مخصصة",
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case "trend":
        return <TrendingUp className="h-5 w-5 text-blue-500" />;
      case "alert":
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case "opportunity":
        return <Lightbulb className="h-5 w-5 text-yellow-500" />;
      default:
        return <Sparkles className="h-5 w-5" />;
    }
  };

  const getColorClass = (type: string) => {
    switch (type) {
      case "trend":
        return "bg-blue-500/10 border-blue-500/20 hover:bg-blue-500/15";
      case "alert":
        return "bg-red-500/10 border-red-500/20 hover:bg-red-500/15";
      case "opportunity":
        return "bg-yellow-500/10 border-yellow-500/20 hover:bg-yellow-500/15";
      default:
        return "bg-slate-500/10 border-slate-500/20 hover:bg-slate-500/15";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Sparkles className="h-6 w-6 text-purple-500" />
        <h3 className="text-lg font-semibold">توقعات وتوصيات ذكية</h3>
      </div>

      {/* Predictions */}
      <div className="space-y-4">
        {predictions.map((prediction) => (
          <Card
            key={prediction.id}
            className={`cursor-pointer transition-all duration-200 ${getColorClass(
              prediction.type
            )}`}
          >
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">
                  {getIcon(prediction.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-medium text-foreground">
                        {prediction.title}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {prediction.description}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center gap-2">
                      <div className="text-xs text-muted-foreground">دقة التنبؤ:</div>
                      <div className="flex items-center gap-1">
                        <div className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                            style={{ width: `${prediction.confidence}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium">{prediction.confidence}%</span>
                      </div>
                    </div>
                    {prediction.action && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-xs h-7"
                        onClick={() => console.log(`Action: ${prediction.id}`)}
                      >
                        {prediction.action}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Smart Recommendations */}
      <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-purple-500" />
            التوصيات الذكية
          </CardTitle>
          <CardDescription>بناءً على تحليل بيانات دراستك</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2 p-3 rounded-lg bg-background/50">
            <p className="font-medium text-sm flex items-center gap-2">
              <span className="text-lg">🎯</span>
              ركز على المواد الضعيفة أولاً
            </p>
            <p className="text-xs text-muted-foreground">
              ابدأ بمادة اللغة الإنجليزية لمدة 2-3 ساعات يومياً قبل الانتقال للمواد الأخرى
            </p>
          </div>
          <div className="space-y-2 p-3 rounded-lg bg-background/50">
            <p className="font-medium text-sm flex items-center gap-2">
              <span className="text-lg">⏰</span>
              أفضل وقت للدراسة: 6-8 مساءً
            </p>
            <p className="text-xs text-muted-foreground">
              إنتاجيتك تصل ذروتها في هذا الوقت. خطط جلساتك الدراسية بناءً على هذا
            </p>
          </div>
          <div className="space-y-2 p-3 rounded-lg bg-background/50">
            <p className="font-medium text-sm flex items-center gap-2">
              <span className="text-lg">📚</span>
              استخدم تقنية البطاقات التعليمية
            </p>
            <p className="text-xs text-muted-foreground">
              هذه التقنية أثبتت فعاليتها معك بنسبة 34% أفضل من الطرق الأخرى
            </p>
          </div>
          <div className="space-y-2 p-3 rounded-lg bg-background/50">
            <p className="font-medium text-sm flex items-center gap-2">
              <span className="text-lg">💤</span>
              احصل على 8 ساعات نوم
            </p>
            <p className="text-xs text-muted-foreground">
              قلة النوم تؤثر على تركيزك بنسبة 23%. حاول النوم قبل الساعة 11 مساءً
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
