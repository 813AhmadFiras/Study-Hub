import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CheckCircle2, Info, Lightbulb, Trophy, Clock, BookOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Notification {
  id: string;
  type: "alert" | "success" | "info" | "tip" | "achievement";
  title: string;
  description: string;
  timestamp: string;
  actionable?: boolean;
}

export function SmartNotifications() {
  const notifications: Notification[] = [
    {
      id: "1",
      type: "achievement",
      title: "🏆 إنجاز جديد!",
      description: "لقد أكملت 50 جلسة بومودورو هذا الشهر",
      timestamp: "منذ ساعة",
      actionable: true,
    },
    {
      id: "2",
      type: "alert",
      title: "⏰ تنبيه الامتحان",
      description: "امتحان الرياضيات خلال 3 أيام",
      timestamp: "منذ 2 ساعة",
      actionable: true,
    },
    {
      id: "3",
      type: "tip",
      title: "💡 نصيحة ذكية",
      description: "جرب الدراسة في الساعة 6 مساءً - أفضل وقت تركيز لديك",
      timestamp: "منذ 4 ساعات",
      actionable: false,
    },
    {
      id: "4",
      type: "success",
      title: "✅ هدف مكتمل",
      description: "لقد أكملت 80% من أهدافك الأسبوعية",
      timestamp: "منذ 6 ساعات",
      actionable: false,
    },
    {
      id: "5",
      type: "info",
      title: "ℹ️ معلومة مهمة",
      description: "تم تحديث المنصة بميزات جديدة",
      timestamp: "منذ يوم",
      actionable: false,
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case "alert":
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case "success":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case "tip":
        return <Lightbulb className="h-5 w-5 text-yellow-500" />;
      case "achievement":
        return <Trophy className="h-5 w-5 text-amber-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getColorClass = (type: string) => {
    switch (type) {
      case "alert":
        return "bg-red-500/10 border-red-500/20 hover:bg-red-500/15";
      case "success":
        return "bg-green-500/10 border-green-500/20 hover:bg-green-500/15";
      case "tip":
        return "bg-yellow-500/10 border-yellow-500/20 hover:bg-yellow-500/15";
      case "achievement":
        return "bg-amber-500/10 border-amber-500/20 hover:bg-amber-500/15";
      default:
        return "bg-blue-500/10 border-blue-500/20 hover:bg-blue-500/15";
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-4">الإشعارات الذكية</h3>
        <div className="space-y-3">
          {notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`cursor-pointer transition-all duration-200 ${getColorClass(notification.type)}`}
            >
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 mt-1">
                    {getIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-medium text-foreground">
                          {notification.title}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {notification.description}
                        </p>
                      </div>
                      {notification.actionable && (
                        <Badge variant="secondary" className="flex-shrink-0">
                          إجراء
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      {notification.timestamp}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Upcoming Events */}
      <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-purple-500" />
            الأحداث القادمة
          </CardTitle>
          <CardDescription>أهم الأحداث في الأسابيع القادمة</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3 p-3 rounded-lg bg-background/50">
            <Clock className="h-4 w-4 text-purple-500 mt-1 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">امتحان الرياضيات</p>
              <p className="text-xs text-muted-foreground">الخميس - 15 يناير</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg bg-background/50">
            <BookOpen className="h-4 w-4 text-purple-500 mt-1 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">تسليم مشروع العلوم</p>
              <p className="text-xs text-muted-foreground">الجمعة - 16 يناير</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg bg-background/50">
            <Clock className="h-4 w-4 text-purple-500 mt-1 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">اختبار اللغة الإنجليزية</p>
              <p className="text-xs text-muted-foreground">الاثنين - 19 يناير</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { Calendar } from "lucide-react";
