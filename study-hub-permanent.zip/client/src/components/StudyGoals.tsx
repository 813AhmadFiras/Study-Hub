import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Target, Flame, Star, Award } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Goal {
  id: string;
  title: string;
  description: string;
  progress: number;
  target: number;
  unit: string;
  deadline: string;
  priority: "high" | "medium" | "low";
  streak?: number;
}

export function StudyGoals() {
  const goals: Goal[] = [
    {
      id: "1",
      title: "إكمال فصل الرياضيات",
      description: "دراسة جميع دروس الفصل الثالث",
      progress: 75,
      target: 100,
      unit: "%",
      deadline: "20 يناير",
      priority: "high",
      streak: 12,
    },
    {
      id: "2",
      title: "مراجعة 100 بطاقة تعليمية",
      description: "مراجعة البطاقات التعليمية الأساسية",
      progress: 68,
      target: 100,
      unit: "بطاقة",
      deadline: "25 يناير",
      priority: "medium",
      streak: 8,
    },
    {
      id: "3",
      title: "إكمال 50 جلسة بومودورو",
      description: "جلسات دراسة منتظمة هذا الشهر",
      progress: 42,
      target: 50,
      unit: "جلسة",
      deadline: "31 يناير",
      priority: "high",
      streak: 5,
    },
    {
      id: "4",
      title: "كتابة 20 ملاحظة شاملة",
      description: "ملاحظات منظمة وشاملة لكل مادة",
      progress: 15,
      target: 20,
      unit: "ملاحظة",
      deadline: "28 يناير",
      priority: "low",
      streak: 3,
    },
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500/10 text-red-700 border-red-500/20";
      case "medium":
        return "bg-yellow-500/10 text-yellow-700 border-yellow-500/20";
      default:
        return "bg-green-500/10 text-green-700 border-green-500/20";
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high":
        return "أولوية عالية";
      case "medium":
        return "أولوية متوسطة";
      default:
        return "أولوية منخفضة";
    }
  };

  return (
    <div className="space-y-6">
      {/* Goals Summary */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">الأهداف النشطة</p>
                <p className="text-2xl font-bold mt-1">4</p>
              </div>
              <Target className="h-8 w-8 text-blue-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">متوسط التقدم</p>
                <p className="text-2xl font-bold mt-1">75%</p>
              </div>
              <Flame className="h-8 w-8 text-orange-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">الأهداف المكتملة</p>
                <p className="text-2xl font-bold mt-1">12</p>
              </div>
              <Award className="h-8 w-8 text-purple-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Goals List */}
      <div className="space-y-4">
        {goals.map((goal) => (
          <Card key={goal.id} className="hover:shadow-lg transition-all duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <CardTitle className="text-base">{goal.title}</CardTitle>
                  <CardDescription className="mt-1">{goal.description}</CardDescription>
                </div>
                <Badge variant="outline" className={getPriorityColor(goal.priority)}>
                  {getPriorityLabel(goal.priority)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Progress Bar */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">
                    {goal.progress} / {goal.target} {goal.unit}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {Math.round((goal.progress / goal.target) * 100)}%
                  </span>
                </div>
                <Progress 
                  value={(goal.progress / goal.target) * 100} 
                  className="h-2"
                />
              </div>

              {/* Goal Info */}
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <span>📅</span>
                    <span>{goal.deadline}</span>
                  </div>
                  {goal.streak && (
                    <div className="flex items-center gap-1 text-orange-500">
                      <Flame className="h-4 w-4" />
                      <span>{goal.streak} يوم متتالي</span>
                    </div>
                  )}
                </div>
                <button className="text-primary hover:underline text-xs font-medium">
                  تحديث التقدم
                </button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Achievements */}
      <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-amber-500" />
            الإنجازات
          </CardTitle>
          <CardDescription>الإنجازات التي حققتها هذا الشهر</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-background/50">
              <div className="text-2xl">🏆</div>
              <div>
                <p className="font-medium text-sm">الدارس المثابر</p>
                <p className="text-xs text-muted-foreground">7 أيام دراسة متتالية</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-background/50">
              <div className="text-2xl">⭐</div>
              <div>
                <p className="font-medium text-sm">الطالب المنظم</p>
                <p className="text-xs text-muted-foreground">50 ملاحظة مكتملة</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-background/50">
              <div className="text-2xl">🔥</div>
              <div>
                <p className="font-medium text-sm">سيد التركيز</p>
                <p className="text-xs text-muted-foreground">100 جلسة بومودورو</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-background/50">
              <div className="text-2xl">📚</div>
              <div>
                <p className="font-medium text-sm">عالم المعرفة</p>
                <p className="text-xs text-muted-foreground">500 بطاقة تعليمية</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
