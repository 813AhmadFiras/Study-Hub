import { usePlan } from "@/_core/hooks/usePlan";
import { AlertCircle, Zap, Crown } from "lucide-react";
import { Button } from "./ui/button";

export function PlanBanner() {
  const { plan, isTrial, trialDaysRemaining } = usePlan();

  if (plan === "free") {
    return (
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Zap className="w-5 h-5 text-blue-400" />
            <div>
              <p className="font-semibold text-white">أنت تستخدم الخطة المجانية</p>
              <p className="text-sm text-slate-400">
                ترقّ إلى Premium للحصول على ميزات متقدمة
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="border-blue-500/50 hover:bg-blue-500/10"
          >
            ترقية
          </Button>
        </div>
      </div>
    );
  }

  if (isTrial && trialDaysRemaining > 0) {
    return (
      <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Crown className="w-5 h-5 text-purple-400" />
            <div>
              <p className="font-semibold text-white">
                تجربة مجانية - {trialDaysRemaining} أيام متبقية
              </p>
              <p className="text-sm text-slate-400">
                استمتع بجميع ميزات Premium
              </p>
            </div>
          </div>
          {trialDaysRemaining <= 3 && (
            <AlertCircle className="w-5 h-5 text-orange-400" />
          )}
        </div>
      </div>
    );
  }

  if (isTrial && trialDaysRemaining <= 0) {
    return (
      <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-orange-400" />
            <div>
              <p className="font-semibold text-white">انتهت التجربة المجانية</p>
              <p className="text-sm text-slate-400">
                اشترك الآن للاستمرار في استخدام جميع الميزات
              </p>
            </div>
          </div>
          <Button
            size="sm"
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
          >
            اشترك الآن
          </Button>
        </div>
      </div>
    );
  }

  return null;
}
