import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, ScatterChart, Scatter } from "recharts";
import { TrendingUp, TrendingDown, Zap, Target, Brain, Clock } from "lucide-react";

interface AdvancedAnalyticsProps {
  pomodoroSessions?: any[];
  subjects?: any[];
}

export function AdvancedAnalytics({ pomodoroSessions = [], subjects = [] }: AdvancedAnalyticsProps) {
  // Generate weekly data
  const weeklyData = [
    { day: "الاثنين", sessions: 4, focus: 120, productivity: 85 },
    { day: "الثلاثاء", sessions: 6, focus: 180, productivity: 92 },
    { day: "الأربعاء", sessions: 5, focus: 150, productivity: 88 },
    { day: "الخميس", sessions: 7, focus: 210, productivity: 95 },
    { day: "الجمعة", sessions: 3, focus: 90, productivity: 75 },
    { day: "السبت", sessions: 8, focus: 240, productivity: 98 },
    { day: "الأحد", sessions: 6, focus: 180, productivity: 90 },
  ];

  // Subject distribution
  const subjectData = [
    { name: "الرياضيات", value: 35, color: "#3b82f6" },
    { name: "العلوم", value: 25, color: "#10b981" },
    { name: "اللغة العربية", value: 20, color: "#f59e0b" },
    { name: "اللغة الإنجليزية", value: 20, color: "#8b5cf6" },
  ];

  // Performance trend
  const performanceData = [
    { week: "الأسبوع 1", score: 75 },
    { week: "الأسبوع 2", score: 78 },
    { week: "الأسبوع 3", score: 82 },
    { week: "الأسبوع 4", score: 85 },
    { week: "الأسبوع 5", score: 88 },
    { week: "الأسبوع 6", score: 92 },
  ];

  // Study efficiency
  const efficiencyData = [
    { time: "6 AM", efficiency: 45 },
    { time: "9 AM", efficiency: 75 },
    { time: "12 PM", efficiency: 65 },
    { time: "3 PM", efficiency: 55 },
    { time: "6 PM", efficiency: 85 },
    { time: "9 PM", efficiency: 70 },
  ];

  const stats = [
    {
      title: "إجمالي ساعات الدراسة",
      value: "42.5",
      unit: "ساعة",
      icon: Clock,
      trend: "+12%",
      positive: true,
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "معدل الإنتاجية",
      value: "89%",
      unit: "هذا الأسبوع",
      icon: Zap,
      trend: "+5%",
      positive: true,
      color: "from-yellow-500 to-yellow-600",
    },
    {
      title: "الهدف الأسبوعي",
      value: "92%",
      unit: "مكتمل",
      icon: Target,
      trend: "+8%",
      positive: true,
      color: "from-green-500 to-green-600",
    },
    {
      title: "مستوى التركيز",
      value: "8.5/10",
      unit: "متقدم",
      icon: Brain,
      trend: "-2%",
      positive: false,
      color: "from-purple-500 to-purple-600",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="overflow-hidden group hover:shadow-lg transition-all duration-300">
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-5 group-hover:opacity-10 transition-opacity`} />
              <CardHeader className="pb-2 relative">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </CardTitle>
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.color} bg-opacity-10`}>
                    <Icon className="h-4 w-4 text-foreground" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="relative">
                <div className="flex items-baseline gap-2">
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.unit}</div>
                </div>
                <div className={`text-xs mt-2 flex items-center gap-1 ${stat.positive ? "text-green-600" : "text-red-600"}`}>
                  {stat.positive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {stat.trend}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Weekly Performance */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>الأداء الأسبوعي</CardTitle>
            <CardDescription>ساعات الدراسة والإنتاجية</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={weeklyData}>
                <defs>
                  <linearGradient id="colorSessions" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorProductivity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="day" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip 
                  contentStyle={{ backgroundColor: "rgba(0,0,0,0.8)", border: "1px solid rgba(255,255,255,0.2)" }}
                  cursor={{ fill: "rgba(255,255,255,0.1)" }}
                />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="sessions" 
                  stroke="#3b82f6" 
                  fillOpacity={1} 
                  fill="url(#colorSessions)"
                  name="جلسات الدراسة"
                />
                <Area 
                  type="monotone" 
                  dataKey="productivity" 
                  stroke="#10b981" 
                  fillOpacity={1} 
                  fill="url(#colorProductivity)"
                  name="الإنتاجية %"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Subject Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>توزيع المواد</CardTitle>
            <CardDescription>نسبة الوقت لكل مادة</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={subjectData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {subjectData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `${value}%`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Performance Trend & Study Efficiency */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Performance Trend */}
        <Card>
          <CardHeader>
            <CardTitle>اتجاه الأداء</CardTitle>
            <CardDescription>تطور درجاتك على مدى 6 أسابيع</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="week" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "rgba(0,0,0,0.8)", border: "1px solid rgba(255,255,255,0.2)" }}
                  formatter={(value) => `${value}%`}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#8b5cf6" 
                  strokeWidth={3}
                  dot={{ fill: "#8b5cf6", r: 5 }}
                  activeDot={{ r: 7 }}
                  name="درجة الأداء"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Study Efficiency by Time */}
        <Card>
          <CardHeader>
            <CardTitle>كفاءة الدراسة بالساعة</CardTitle>
            <CardDescription>أفضل أوقات التركيز</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={efficiencyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="time" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip 
                  contentStyle={{ backgroundColor: "rgba(0,0,0,0.8)", border: "1px solid rgba(255,255,255,0.2)" }}
                  formatter={(value) => `${value}%`}
                />
                <Bar 
                  dataKey="efficiency" 
                  fill="#f59e0b" 
                  radius={[8, 8, 0, 0]}
                  name="الكفاءة %"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insights & Recommendations */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-blue-500" />
              رؤى ذكية
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm">
              <p className="font-medium text-foreground">📈 أنت في مسار جيد!</p>
              <p className="text-muted-foreground text-xs mt-1">تحسن أدائك بنسبة 12% هذا الأسبوع</p>
            </div>
            <div className="text-sm">
              <p className="font-medium text-foreground">⏰ أفضل وقت للدراسة</p>
              <p className="text-muted-foreground text-xs mt-1">الساعة 6 مساءً هي أفضل وقت تركيز لديك</p>
            </div>
            <div className="text-sm">
              <p className="font-medium text-foreground">🎯 هدف قريب</p>
              <p className="text-muted-foreground text-xs mt-1">أنت على بعد 3 ساعات من تحقيق هدفك الأسبوعي</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-green-500" />
              التوصيات المخصصة
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm">
              <p className="font-medium text-foreground">💡 جرب تقنية جديدة</p>
              <p className="text-muted-foreground text-xs mt-1">استخدم جلسات بومودورو بفترات 45 دقيقة</p>
            </div>
            <div className="text-sm">
              <p className="font-medium text-foreground">📚 ركز على الضعيفة</p>
              <p className="text-muted-foreground text-xs mt-1">خصص وقتاً إضافياً لمادة اللغة الإنجليزية</p>
            </div>
            <div className="text-sm">
              <p className="font-medium text-foreground">🏆 استمر في التقدم</p>
              <p className="text-muted-foreground text-xs mt-1">أنت على الطريق الصحيح، حافظ على الزخم</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
