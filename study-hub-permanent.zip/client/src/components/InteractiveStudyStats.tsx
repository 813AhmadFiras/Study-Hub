import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Activity, Zap, Target, BookOpen, Clock, TrendingUp } from "lucide-react";

interface StudyStat {
  id: string;
  label: string;
  current: number;
  target: number;
  unit: string;
  icon: React.ReactNode;
  color: string;
  trend?: number;
}

export function InteractiveStudyStats() {
  const [stats, setStats] = useState<StudyStat[]>([
    {
      id: "focus-time",
      label: "وقت التركيز اليومي",
      current: 4.5,
      target: 6,
      unit: "ساعات",
      icon: <Clock className="h-5 w-5" />,
      color: "from-blue-500 to-blue-600",
      trend: 12,
    },
    {
      id: "pomodoro",
      label: "جلسات بومودورو",
      current: 8,
      target: 10,
      unit: "جلسات",
      icon: <Activity className="h-5 w-5" />,
      color: "from-green-500 to-green-600",
      trend: 8,
    },
    {
      id: "flashcards",
      label: "بطاقات مراجعة",
      current: 45,
      target: 50,
      unit: "بطاقة",
      icon: <BookOpen className="h-5 w-5" />,
      color: "from-purple-500 to-purple-600",
      trend: -2,
    },
    {
      id: "productivity",
      label: "مستوى الإنتاجية",
      current: 87,
      target: 100,
      unit: "%",
      icon: <Zap className="h-5 w-5" />,
      color: "from-yellow-500 to-yellow-600",
      trend: 5,
    },
  ]);

  const [animatedValues, setAnimatedValues] = useState<Record<string, number>>({});

  // Animate values on mount
  useEffect(() => {
    const timers = stats.map((stat) => {
      return setTimeout(() => {
        setAnimatedValues((prev) => ({
          ...prev,
          [stat.id]: stat.current,
        }));
      }, 100);
    });

    return () => timers.forEach(clearTimeout);
  }, [stats]);

  // Simulate live updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prevStats) =>
        prevStats.map((stat) => {
          const randomChange = (Math.random() - 0.5) * 0.5;
          const newValue = Math.min(
            stat.target,
            Math.max(0, stat.current + randomChange)
          );
          return { ...stat, current: newValue };
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">إحصائيات الدراسة المباشرة</h3>
        <Button variant="outline" size="sm">
          تحديث الآن
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {stats.map((stat) => {
          const percentage = (animatedValues[stat.id] || stat.current) / stat.target * 100;
          const isPositiveTrend = (stat.trend || 0) >= 0;

          return (
            <Card
              key={stat.id}
              className="group hover:shadow-lg transition-all duration-300 cursor-pointer"
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium">
                    {stat.label}
                  </CardTitle>
                  <div
                    className={`p-2 rounded-lg bg-gradient-to-br ${stat.color} bg-opacity-10 group-hover:bg-opacity-20 transition-all`}
                  >
                    {stat.icon}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Current Value */}
                <div className="flex items-baseline gap-2">
                  <div className="text-2xl font-bold">
                    {animatedValues[stat.id]?.toFixed(1) || stat.current.toFixed(1)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    / {stat.target} {stat.unit}
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-2">
                  <Progress value={Math.min(100, percentage)} className="h-2" />
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {Math.round(Math.min(100, percentage))}%
                    </span>
                    {stat.trend !== undefined && (
                      <span
                        className={`flex items-center gap-1 ${
                          isPositiveTrend ? "text-green-500" : "text-red-500"
                        }`}
                      >
                        <TrendingUp className="h-3 w-3" />
                        {isPositiveTrend ? "+" : ""}{stat.trend}%
                      </span>
                    )}
                  </div>
                </div>

                {/* Quick Action */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-xs h-8"
                  onClick={() => {
                    // Handle quick action
                    console.log(`Quick action for ${stat.id}`);
                  }}
                >
                  تحديث الآن
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Live Activity Feed */}
      <Card className="bg-gradient-to-br from-slate-500/10 to-slate-600/10 border-slate-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-slate-500" />
            النشاط المباشر
          </CardTitle>
          <CardDescription>آخر التحديثات على إحصائياتك</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center gap-3 text-sm">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span>تم إضافة جلسة بومودورو جديدة</span>
            <span className="text-xs text-muted-foreground ml-auto">منذ 2 دقيقة</span>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            <span>تم مراجعة 5 بطاقات تعليمية</span>
            <span className="text-xs text-muted-foreground ml-auto">منذ 5 دقائق</span>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
            <span>تم تحديث ملاحظة في الرياضيات</span>
            <span className="text-xs text-muted-foreground ml-auto">منذ 10 دقائق</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
