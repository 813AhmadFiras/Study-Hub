import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { BarChart3, TrendingUp, PieChart as PieChartIcon } from "lucide-react";

interface StatsChartsProps {
  pomodoroSessions?: Array<{
    id: number;
    duration: number;
    completedAt: Date | null;
    subjectId: number | null;
    completed: boolean | null;
  }>;
  subjects?: Array<{
    id: number;
    name: string;
    color: string | null;
  }>;
}

export function StatsCharts({ pomodoroSessions = [], subjects = [] }: StatsChartsProps) {
  // إعداد بيانات الرسم البياني الخطي (آخر 7 أيام)
  const getLast7DaysData = () => {
    const days = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dayName = date.toLocaleDateString('ar-SA', { weekday: 'short' });
      
      const sessionsCount = pomodoroSessions.filter(session => {
        if (!session.completedAt || !session.completed) return false;
        const sessionDate = new Date(session.completedAt);
        return sessionDate.toDateString() === date.toDateString();
      }).length;
      
      const totalMinutes = pomodoroSessions
        .filter(session => {
          if (!session.completedAt || !session.completed) return false;
          const sessionDate = new Date(session.completedAt);
          return sessionDate.toDateString() === date.toDateString();
        })
        .reduce((sum, session) => sum + session.duration, 0);
      
      days.push({
        day: dayName,
        sessions: sessionsCount,
        minutes: totalMinutes,
      });
    }
    
    return days;
  };

  // إعداد بيانات الرسم البياني الدائري (توزيع الوقت حسب المواد)
  const getSubjectsDistribution = () => {
    const subjectStats = subjects.map(subject => {
      const subjectSessions = pomodoroSessions.filter(
        session => session.subjectId === subject.id && session.completed
      );
      const totalMinutes = subjectSessions.reduce(
        (sum, session) => sum + session.duration,
        0
      );
      
      return {
        name: subject.name,
        value: totalMinutes,
        color: subject.color || "#3b82f6",
      };
    });
    
    // إضافة الجلسات بدون مادة
    const noSubjectSessions = pomodoroSessions.filter(
      session => !session.subjectId && session.completed
    );
    const noSubjectMinutes = noSubjectSessions.reduce(
      (sum, session) => sum + session.duration,
      0
    );
    
    if (noSubjectMinutes > 0) {
      subjectStats.push({
        name: "بدون مادة",
        value: noSubjectMinutes,
        color: "#94a3b8",
      });
    }
    
    return subjectStats.filter(stat => stat.value > 0);
  };

  // إعداد بيانات الرسم البياني العمودي (الإنتاجية الأسبوعية)
  const getWeeklyProductivity = () => {
    const weeks = [];
    const today = new Date();
    
    for (let i = 3; i >= 0; i--) {
      const weekStart = new Date(today);
      weekStart.setDate(weekStart.getDate() - (i * 7) - 7);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      
      const weekLabel = `الأسبوع ${4 - i}`;
      
      const weekSessions = pomodoroSessions.filter(session => {
        if (!session.completedAt || !session.completed) return false;
        const sessionDate = new Date(session.completedAt);
        return sessionDate >= weekStart && sessionDate <= weekEnd;
      });
      
      const totalMinutes = weekSessions.reduce(
        (sum, session) => sum + session.duration,
        0
      );
      const totalHours = Math.round(totalMinutes / 60 * 10) / 10;
      
      weeks.push({
        week: weekLabel,
        hours: totalHours,
        sessions: weekSessions.length,
      });
    }
    
    return weeks;
  };

  const last7DaysData = getLast7DaysData();
  const subjectsDistribution = getSubjectsDistribution();
  const weeklyProductivity = getWeeklyProductivity();

  const COLORS = subjectsDistribution.map(item => item.color);

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {/* رسم بياني خطي - جلسات آخر 7 أيام */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            جلسات الدراسة - آخر 7 أيام
          </CardTitle>
          <CardDescription>عدد الجلسات والدقائق المكتملة يومياً</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={last7DaysData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip
                contentStyle={{ direction: 'rtl' }}
                labelStyle={{ direction: 'rtl' }}
              />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="sessions"
                stroke="#3b82f6"
                name="عدد الجلسات"
                strokeWidth={2}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="minutes"
                stroke="#10b981"
                name="الدقائق"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* رسم بياني دائري - توزيع الوقت */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChartIcon className="h-5 w-5" />
            توزيع الوقت حسب المواد
          </CardTitle>
          <CardDescription>إجمالي الدقائق لكل مادة</CardDescription>
        </CardHeader>
        <CardContent>
          {subjectsDistribution.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={subjectsDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.name}: ${entry.value}د`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {subjectsDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ direction: 'rtl' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[300px]">
              <p className="text-sm text-muted-foreground">لا توجد بيانات لعرضها</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* رسم بياني عمودي - الإنتاجية الأسبوعية */}
      <Card className="lg:col-span-3">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            الإنتاجية الأسبوعية
          </CardTitle>
          <CardDescription>إجمالي الساعات والجلسات لآخر 4 أسابيع</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklyProductivity}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip
                contentStyle={{ direction: 'rtl' }}
                labelStyle={{ direction: 'rtl' }}
              />
              <Legend />
              <Bar
                yAxisId="left"
                dataKey="hours"
                fill="#8b5cf6"
                name="الساعات"
              />
              <Bar
                yAxisId="right"
                dataKey="sessions"
                fill="#f59e0b"
                name="عدد الجلسات"
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
