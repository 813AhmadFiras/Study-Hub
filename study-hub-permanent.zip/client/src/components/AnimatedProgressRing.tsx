import { useEffect, useRef } from "react";

interface AnimatedProgressRingProps {
  percentage: number;
  label: string;
  color?: string;
  size?: number;
}

export function AnimatedProgressRing({
  percentage,
  label,
  color = "#3b82f6",
  size = 120,
}: AnimatedProgressRingProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const currentPercentageRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const centerX = size / 2;
    const centerY = size / 2;
    const radius = size / 2 - 10;
    const lineWidth = 8;

    const animate = () => {
      // Clear canvas
      ctx.clearRect(0, 0, size, size);

      // Draw background circle
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
      ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
      ctx.lineWidth = lineWidth;
      ctx.stroke();

      // Animate to target percentage
      if (currentPercentageRef.current < percentage) {
        currentPercentageRef.current += (percentage - currentPercentageRef.current) * 0.1;
      }

      // Draw progress circle
      const startAngle = -Math.PI / 2;
      const endAngle = startAngle + (currentPercentageRef.current / 100) * 2 * Math.PI;

      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;
      ctx.lineCap = "round";
      ctx.stroke();

      // Draw percentage text
      ctx.font = `bold ${size / 3}px Arial`;
      ctx.fillStyle = color;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(`${Math.round(currentPercentageRef.current)}%`, centerX, centerY - 10);

      // Draw label
      ctx.font = `12px Arial`;
      ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
      ctx.fillText(label, centerX, centerY + 20);

      if (currentPercentageRef.current < percentage) {
        animationRef.current = requestAnimationFrame(animate);
      }
    };

    animate();

    return () => {
      if (animationRef.current !== null) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [percentage, label, color, size]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className="drop-shadow-lg"
    />
  );
}
