import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      "nav": {
        "dashboard": "Dashboard",
        "search": "Global Search",
        "subjects": "Subjects",
        "notes": "Notes",
        "flashcards": "Flashcards",
        "pomodoro": "Pomodoro",
        "calendar": "Calendar",
        "files": "Files",
        "solver": "Problem Solver",
        "recorder": "Voice Recorder",
        "chat": "AI Assistant",
        "notifications": "Notifications",
        "settings": "Settings",
        "logout": "Logout"
      },
      "settings": {
        "title": "Settings",
        "appearance": "Appearance",
        "theme": "Theme",
        "light": "Light",
        "dark": "Dark",
        "system": "System",
        "language": "Language",
        "arabic": "Arabic",
        "english": "English",
        "profile": "Profile",
        "name": "Name",
        "email": "Email",
        "subscription": "Subscription",
        "plan": "Current Plan",
        "free": "Free",
        "premium": "Premium",
        "trial": "Trial",
        "save": "Save Changes"
      },
      "common": {
        "welcome": "Welcome",
        "loading": "Loading...",
        "error": "An error occurred",
        "back": "Back"
      }
    }
  },
  ar: {
    translation: {
      "nav": {
        "dashboard": "لوحة التحكم",
        "search": "البحث الشامل",
        "subjects": "المواد الدراسية",
        "notes": "الملاحظات",
        "flashcards": "البطاقات التعليمية",
        "pomodoro": "مؤقت بومودورو",
        "calendar": "التقويم",
        "files": "الملفات",
        "solver": "حل المسائل",
        "recorder": "تسجيل الصوت",
        "chat": "المساعد الذكي",
        "notifications": "الإشعارات",
        "settings": "الإعدادات",
        "logout": "تسجيل الخروج"
      },
      "settings": {
        "title": "الإعدادات",
        "appearance": "المظهر",
        "theme": "الثيم",
        "light": "فاتح",
        "dark": "داكن",
        "system": "النظام",
        "language": "اللغة",
        "arabic": "العربية",
        "english": "الإنجليزية",
        "profile": "الملف الشخصي",
        "name": "الاسم",
        "email": "البريد الإلكتروني",
        "subscription": "الاشتراك",
        "plan": "الخطة الحالية",
        "free": "مجانية",
        "premium": "بريميوم",
        "trial": "تجريبية",
        "save": "حفظ التغييرات"
      },
      "common": {
        "welcome": "مرحباً",
        "loading": "جاري التحميل...",
        "error": "حدث خطأ ما",
        "back": "رجوع"
      }
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'ar',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
