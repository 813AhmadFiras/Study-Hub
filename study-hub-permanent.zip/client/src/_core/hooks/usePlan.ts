import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export interface PlanLimits {
  dailyMessages: number;
  dailyFileUploads: number;
  maxFileSize: number; // MB
  advancedFeatures: boolean;
  voiceAssistant: boolean;
  smartQuizzes: boolean;
}

const PLAN_LIMITS: Record<string, PlanLimits> = {
  free: {
    dailyMessages: 10,
    dailyFileUploads: 3,
    maxFileSize: 5,
    advancedFeatures: false,
    voiceAssistant: false,
    smartQuizzes: false,
  },
  premium: {
    dailyMessages: 999,
    dailyFileUploads: 999,
    maxFileSize: 100,
    advancedFeatures: true,
    voiceAssistant: true,
    smartQuizzes: true,
  },
  trial: {
    dailyMessages: 999,
    dailyFileUploads: 999,
    maxFileSize: 100,
    advancedFeatures: true,
    voiceAssistant: true,
    smartQuizzes: true,
  },
};

export function usePlan() {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const { data: trialStatus } = trpc.settings.checkTrialStatus.useQuery();
  const [limits, setLimits] = useState<PlanLimits>(PLAN_LIMITS.free);

  useEffect(() => {
    if (settings?.plan) {
      setLimits(PLAN_LIMITS[settings.plan] || PLAN_LIMITS.free);
    }
  }, [settings?.plan]);

  const canUseFeature = (feature: keyof PlanLimits): boolean => {
    if (settings?.plan === "free") {
      return limits[feature] !== false;
    }
    return true;
  };

  const isPremium = settings?.plan === "premium" || settings?.plan === "trial";
  const isTrial = settings?.plan === "trial";

  return {
    plan: settings?.plan || "free",
    language: settings?.language || "ar",
    category: settings?.category || "school",
    isOnboardingComplete: settings?.isOnboardingComplete || false,
    limits,
    canUseFeature,
    isPremium,
    isTrial,
    trialDaysRemaining: trialStatus?.daysRemaining || 0,
    isLoading,
  };
}

export function useCheckFeatureLimit(feature: string) {
  const { data: stats, isLoading } = trpc.settings.getUsageStats.useQuery({
    feature,
  });
  const trackUsageMutation = trpc.settings.trackUsage.useMutation();
  const { plan, limits } = usePlan();

  const canUseFeature = (): boolean => {
    if (plan === "free") {
      const featureLimits = PLAN_LIMITS.free;
      const limitKey = `daily${feature.charAt(0).toUpperCase()}${feature.slice(1)}` as keyof PlanLimits;
      const limit = featureLimits[limitKey];
      
      if (typeof limit === "number") {
        return (stats?.todayCount || 0) < limit;
      }
    }
    return true;
  };

  const trackUsage = async () => {
    await trackUsageMutation.mutateAsync({ feature });
  };

  return {
    canUseFeature: canUseFeature(),
    todayCount: stats?.todayCount || 0,
    trackUsage,
    isLoading,
  };
}
