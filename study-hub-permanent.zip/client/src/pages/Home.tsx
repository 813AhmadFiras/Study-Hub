import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BookOpen, FileText, CreditCard, Timer, Calendar, TrendingUp, Clock, CheckCircle2, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StatsCharts } from "@/components/StatsCharts";

export default function Home() {
  const { data: subjects } = trpc.subjects.list.useQuery();
  const { data: notes } = trpc.notes.list.useQuery();
  const { data: flashcards } = trpc.flashcards.list.useQuery();
  const { data: pomodoroSessions } = trpc.pomodoro.list.useQuery();
  const { data: events } = trpc.events.list.useQuery();

  const stats = [
    {
      title: "المواد الدراسية",
      value: subjects?.length || 0,
      icon: BookOpen,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      href: "/subjects",
    },
    {
      title: "الملاحظات",
      value: notes?.length || 0,
      icon: FileText,
      color: "text-green-600",
      bgColor: "bg-green-100",
      href: "/notes",
    },
    {
      title: "البطاقات التعليمية",
      value: flashcards?.length || 0,
      icon: CreditCard,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      href: "/flashcards",
    },
    {
      title: "جلسات بومودورو",
      value: pomodoroSessions?.length || 0,
      icon: Timer,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
      href: "/pomodoro",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">مرحباً بك في Study Hub</h1>
          <p className="text-muted-foreground mt-2">مركزك الشامل لتنظيم دراستك وتحسين إنتاجيتك</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card
                key={stat.title}
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => (window.location.href = stat.href)}
              >
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </CardTitle>
                  <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`h-4 w-4 ${stat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>إجراءات سريعة</CardTitle>
            <CardDescription>ابدأ بإضافة محتوى جديد لمنصتك الدراسية</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Button
                variant="outline"
                className="w-full justify-start gap-2 h-auto py-4"
                onClick={() => (window.location.href = "/subjects")}
              >
                <BookOpen className="h-5 w-5" />
                <div className="text-right">
                  <div className="font-medium">إضافة مادة دراسية</div>
                  <div className="text-xs text-muted-foreground">نظم موادك الدراسية</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-2 h-auto py-4"
                onClick={() => (window.location.href = "/notes")}
              >
                <FileText className="h-5 w-5" />
                <div className="text-right">
                  <div className="font-medium">كتابة ملاحظة</div>
                  <div className="text-xs text-muted-foreground">دون أفكارك وملاحظاتك</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-2 h-auto py-4"
                onClick={() => (window.location.href = "/flashcards")}
              >
                <CreditCard className="h-5 w-5" />
                <div className="text-right">
                  <div className="font-medium">إنشاء بطاقة تعليمية</div>
                  <div className="text-xs text-muted-foreground">احفظ المعلومات بفعالية</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-2 h-auto py-4"
                onClick={() => (window.location.href = "/pomodoro")}
              >
                <Timer className="h-5 w-5" />
                <div className="text-right">
                  <div className="font-medium">بدء جلسة بومودورو</div>
                  <div className="text-xs text-muted-foreground">ركز على دراستك</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-2 h-auto py-4"
                onClick={() => (window.location.href = "/calendar")}
              >
                <Calendar className="h-5 w-5" />
                <div className="text-right">
                  <div className="font-medium">إضافة حدث</div>
                  <div className="text-xs text-muted-foreground">نظم مواعيدك وامتحاناتك</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="w-full justify-start gap-2 h-auto py-4"
                onClick={() => (window.location.href = "/chat")}
              >
                <TrendingUp className="h-5 w-5" />
                <div className="text-right">
                  <div className="font-medium">المساعد الذكي</div>
                  <div className="text-xs text-muted-foreground">اسأل واحصل على المساعدة</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Charts */}
        <div>
          <h2 className="text-2xl font-bold mb-4">الإحصائيات والتقدم</h2>
          <StatsCharts
            pomodoroSessions={pomodoroSessions}
            subjects={subjects}
          />
        </div>

        {/* Recent Activity */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                الأحداث القادمة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">لا توجد أحداث قادمة حالياً</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5" />
                آخر الإنجازات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">ابدأ بإضافة محتوى لتتبع إنجازاتك</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
