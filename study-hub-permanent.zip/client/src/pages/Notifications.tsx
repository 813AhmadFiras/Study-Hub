import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Bell, Trash2, CheckCircle2, Circle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function Notifications() {
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const { data: notifications, isLoading } = trpc.notifications.list.useQuery();
  const markAsReadMutation = trpc.notifications.markAsRead.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الإشعار");
    },
  });
  const deleteNotificationMutation = trpc.notifications.markAsRead.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الإشعار");
    },
  });

  const filteredNotifications = notifications?.filter((n) => {
    if (filter === "unread") return !n.isRead;
    return true;
  });

  const unreadCount = notifications?.filter((n) => !n.isRead).length || 0;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "exam":
        return "📝";
      case "deadline":
        return "⏰";
      case "task":
        return "✓";
      case "reminder":
        return "🔔";
      default:
        return "ℹ️";
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "exam":
        return "bg-red-100 text-red-800 border-red-200";
      case "deadline":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "task":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "reminder":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const typeLabels: Record<string, string> = {
    exam: "امتحان",
    deadline: "موعد نهائي",
    task: "مهمة",
    reminder: "تذكير",
    other: "آخر",
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">الإشعارات</h1>
            <p className="text-muted-foreground mt-1">
              تتبع جميع الإشعارات والتذكيرات المهمة
            </p>
          </div>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="text-lg px-3 py-1">
              {unreadCount} جديد
            </Badge>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
          >
            جميع الإشعارات ({notifications?.length || 0})
          </Button>
          <Button
            variant={filter === "unread" ? "default" : "outline"}
            onClick={() => setFilter("unread")}
          >
            غير المقروءة ({unreadCount})
          </Button>

        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {isLoading ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                جاري تحميل الإشعارات...
              </CardContent>
            </Card>
          ) : filteredNotifications && filteredNotifications.length > 0 ? (
            filteredNotifications.map((notification) => (
              <Card
                key={notification.id}
                className={`transition-all ${
                  !notification.isRead ? "border-primary/50 bg-primary/5" : ""
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="text-2xl mt-1">
                      {getNotificationIcon(notification.type)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <h3 className="font-semibold">
                            {notification.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {notification.content}
                          </p>
                        </div>
                        <Badge
                          variant="secondary"
                          className={`whitespace-nowrap ${getNotificationColor(
                            notification.type
                          )}`}
                        >
                          {typeLabels[notification.type] || notification.type}
                        </Badge>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-3">
                        <span>
                          {formatDistanceToNow(
                            new Date(notification.createdAt),
                            { locale: ar, addSuffix: true }
                          )}
                        </span>
                        {notification.relatedId && (
                          <>
                            <span>•</span>
                            <span>
                              {notification.relatedType === "subject"
                                ? "مادة"
                                : notification.relatedType === "event"
                                ? "حدث"
                                : "عنصر"}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {!notification.isRead && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            markAsReadMutation.mutate({
                              id: notification.id,
                            })
                          }
                          disabled={markAsReadMutation.isPending}
                          title="تحديد كمقروء"
                        >
                          <Circle className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          deleteNotificationMutation.mutate({
                            id: notification.id,
                          })
                        }
                        disabled={deleteNotificationMutation.isPending}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">لا توجد إشعارات</h3>
                <p className="text-muted-foreground">
                  {filter === "unread"
                    ? "جميع إشعاراتك مقروءة!"
                    : "لا توجد إشعارات حتى الآن"}
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Notification Settings Info */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">معلومات الإشعارات</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>
              • ستتلقى إشعارات تلقائية عند اقتراب الامتحانات والمواعيد النهائية
            </p>
            <p>
              • يمكنك تحديد الإشعارات كمقروءة بالضغط على الأيقونة الدائرية
            </p>
            <p>• الإشعارات المقروءة تظل في السجل لمراجعتك لاحقاً</p>
            <p>
              • يمكنك حذف الإشعارات الفردية أو جميع الإشعارات دفعة واحدة
            </p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
