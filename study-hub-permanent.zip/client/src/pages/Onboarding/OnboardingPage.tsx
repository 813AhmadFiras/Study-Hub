import { useState, useEffect } from "react";
import { LanguageSelection } from "./LanguageSelection";
import { CategorySelection } from "./CategorySelection";
import { PlanSelection } from "./PlanSelection";

type OnboardingStep = "language" | "category" | "plan" | "complete";

export function OnboardingPage() {
  const [step, setStep] = useState<OnboardingStep>("language");
  const [language, setLanguage] = useState("ar");
  const [category, setCategory] = useState<"school" | "university">("school");
  const [plan, setPlan] = useState<"free" | "premium" | "trial">("trial");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // تطبيق اللغة على الـ document
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  }, [language]);

  const handleLanguageSelect = (lang: string) => {
    setLanguage(lang);
    setStep("category");
  };

  const handleCategorySelect = (cat: "school" | "university") => {
    setCategory(cat);
    setStep("plan");
  };

  const handlePlanSelect = async (selectedPlan: "free" | "premium" | "trial") => {
    setPlan(selectedPlan);
    setIsLoading(true);

    try {
      // حفظ في localStorage
      localStorage.setItem(
        "onboarding",
        JSON.stringify({
          language,
          category,
          plan: selectedPlan,
          completedAt: new Date().toISOString(),
        })
      );

      // إذا كانت التجربة المجانية، حفظ تاريخ البداية والنهاية
      if (selectedPlan === "trial") {
        const trialStartDate = new Date();
        const trialEndDate = new Date(
          trialStartDate.getTime() + 7 * 24 * 60 * 60 * 1000
        );
        localStorage.setItem(
          "trialDates",
          JSON.stringify({
            startDate: trialStartDate.toISOString(),
            endDate: trialEndDate.toISOString(),
          })
        );
      }

      setStep("complete");
      // الانتقال للصفحة الرئيسية بعد ثانية
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
    } catch (error) {
      console.error("Failed to save settings:", error);
      setIsLoading(false);
    }
  };

  if (isLoading && step === "complete") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white text-lg">جاري الإعداد...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {step === "language" && (
        <LanguageSelection onSelect={handleLanguageSelect} />
      )}
      {step === "category" && (
        <CategorySelection onSelect={handleCategorySelect} language={language} />
      )}
      {step === "plan" && (
        <PlanSelection onSelect={handlePlanSelect} language={language} />
      )}
    </>
  );
}
