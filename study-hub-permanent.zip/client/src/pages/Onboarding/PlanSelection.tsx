import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, Zap, Crown, Sparkles } from "lucide-react";

interface PlanSelectionProps {
  onSelect: (plan: "free" | "premium" | "trial") => void;
  language: string;
}

const translations = {
  ar: {
    title: "اختر خطتك",
    subtitle: "ابدأ مع الخطة المناسبة لك",
    free: "مجاني",
    premium: "متميز",
    trial: "تجربة مجانية",
    trialDays: "7 أيام",
    perMonth: "شهرياً",
    freePlan: "خطة مجانية",
    premiumPlan: "خطة متميزة",
    trialPlan: "تجربة مجانية",
    features: {
      free: [
        "رسائل محدودة يومياً",
        "رفع ملفات محدود",
        "مهام دراسية أساسية",
        "بدون مساعد صوتي",
      ],
      premium: [
        "رسائل غير محدودة",
        "تلخيص ملفات كبيرة",
        "اختبارات ذكية",
        "مساعد صوتي",
        "خطط دراسية تلقائية",
        "وضع التركيز المتقدم",
      ],
      trial: [
        "كل ميزات Premium",
        "لمدة 7 أيام",
        "بدون بطاقة ائتمان",
        "إلغاء في أي وقت",
      ],
    },
    start: "ابدأ الآن",
    startTrial: "ابدأ التجربة",
    select: "اختر",
    recommended: "موصى به",
  },
  en: {
    title: "Choose Your Plan",
    subtitle: "Start with the plan that's right for you",
    free: "Free",
    premium: "Premium",
    trial: "Free Trial",
    trialDays: "7 Days",
    perMonth: "/month",
    freePlan: "Free Plan",
    premiumPlan: "Premium Plan",
    trialPlan: "Free Trial",
    features: {
      free: [
        "Limited daily messages",
        "Limited file uploads",
        "Basic study tasks",
        "No voice assistant",
      ],
      premium: [
        "Unlimited messages",
        "Large file summarization",
        "Smart quizzes",
        "Voice assistant",
        "Automatic study plans",
        "Advanced focus mode",
      ],
      trial: [
        "All Premium features",
        "For 7 days",
        "No credit card needed",
        "Cancel anytime",
      ],
    },
    start: "Start Now",
    startTrial: "Start Trial",
    select: "Select",
    recommended: "Recommended",
  },
  fr: {
    title: "Choisissez votre plan",
    subtitle: "Commencez avec le plan qui vous convient",
    free: "Gratuit",
    premium: "Premium",
    trial: "Essai gratuit",
    trialDays: "7 jours",
    perMonth: "/mois",
    freePlan: "Plan gratuit",
    premiumPlan: "Plan Premium",
    trialPlan: "Essai gratuit",
    features: {
      free: [
        "Messages limités par jour",
        "Téléchargements de fichiers limités",
        "Tâches d'étude de base",
        "Pas d'assistant vocal",
      ],
      premium: [
        "Messages illimités",
        "Résumé de gros fichiers",
        "Quiz intelligents",
        "Assistant vocal",
        "Plans d'étude automatiques",
        "Mode de concentration avancé",
      ],
      trial: [
        "Toutes les fonctionnalités Premium",
        "Pendant 7 jours",
        "Pas de carte de crédit",
        "Annuler à tout moment",
      ],
    },
    start: "Commencer",
    startTrial: "Essayer",
    select: "Sélectionner",
    recommended: "Recommandé",
  },
  es: {
    title: "Elige tu plan",
    subtitle: "Comienza con el plan adecuado para ti",
    free: "Gratis",
    premium: "Premium",
    trial: "Prueba gratuita",
    trialDays: "7 días",
    perMonth: "/mes",
    freePlan: "Plan gratuito",
    premiumPlan: "Plan Premium",
    trialPlan: "Prueba gratuita",
    features: {
      free: [
        "Mensajes limitados por día",
        "Cargas de archivos limitadas",
        "Tareas de estudio básicas",
        "Sin asistente de voz",
      ],
      premium: [
        "Mensajes ilimitados",
        "Resumen de archivos grandes",
        "Pruebas inteligentes",
        "Asistente de voz",
        "Planes de estudio automáticos",
        "Modo de enfoque avanzado",
      ],
      trial: [
        "Todas las funciones Premium",
        "Por 7 días",
        "Sin tarjeta de crédito",
        "Cancelar en cualquier momento",
      ],
    },
    start: "Comenzar",
    startTrial: "Probar",
    select: "Seleccionar",
    recommended: "Recomendado",
  },
};

export function PlanSelection({ onSelect, language }: PlanSelectionProps) {
  const [selected, setSelected] = useState<"free" | "premium" | "trial">("trial");
  const t = translations[language as keyof typeof translations] || translations.ar;

  const plans = [
    {
      id: "free" as const,
      name: t.freePlan,
      price: "0",
      icon: Zap,
      features: t.features.free,
      recommended: false,
    },
    {
      id: "trial" as const,
      name: t.trialPlan,
      price: t.trialDays,
      icon: Sparkles,
      features: t.features.trial,
      recommended: true,
    },
    {
      id: "premium" as const,
      name: t.premiumPlan,
      price: "9.99",
      icon: Crown,
      features: t.features.premium,
      recommended: false,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-white mb-2">
            {t.title}
          </h1>
          <p className="text-slate-400">
            {t.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const isSelected = selected === plan.id;

            return (
              <button
                key={plan.id}
                onClick={() => setSelected(plan.id)}
                className={`relative p-6 rounded-lg border-2 transition-all ${
                  isSelected
                    ? "border-blue-500 bg-blue-500/10"
                    : "border-slate-600 bg-slate-700/50 hover:border-slate-500"
                }`}
              >
                {plan.recommended && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                    {t.recommended}
                  </div>
                )}

                <div className="flex justify-center mb-4">
                  <div className="bg-gradient-to-br from-blue-400 to-purple-600 p-4 rounded-full">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-white mb-2">
                  {plan.name}
                </h3>

                <div className="mb-6">
                  <span className="text-3xl font-bold text-white">
                    {plan.price}
                  </span>
                  {plan.id !== "trial" && (
                    <span className="text-slate-400 text-sm">
                      {t.perMonth}
                    </span>
                  )}
                </div>

                <ul className="space-y-3 mb-6 text-left">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-slate-300">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>

        <div className="flex justify-center">
          <Button
            onClick={() => onSelect(selected)}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-8 rounded-lg transition-all"
          >
            {selected === "trial" ? t.startTrial : t.start}
          </Button>
        </div>
      </div>
    </div>
  );
}
