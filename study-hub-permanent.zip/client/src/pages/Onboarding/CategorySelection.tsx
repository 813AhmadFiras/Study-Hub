import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, GraduationCap } from "lucide-react";

interface CategorySelectionProps {
  onSelect: (category: "school" | "university") => void;
  language: string;
}

const translations = {
  ar: {
    title: "ما نوع دراستك؟",
    subtitle: "اختر الفئة التي تنطبق عليك",
    school: "طالب مدرسة",
    university: "طالب جامعة",
    schoolDesc: "المرحلة الابتدائية والإعدادية والثانوية",
    universityDesc: "الدراسة الجامعية والعليا",
    next: "متابعة",
  },
  en: {
    title: "What's your education level?",
    subtitle: "Select the category that applies to you",
    school: "School Student",
    university: "University Student",
    schoolDesc: "Primary, middle, and high school",
    universityDesc: "University and postgraduate studies",
    next: "Continue",
  },
  fr: {
    title: "Quel est votre niveau d'études?",
    subtitle: "Sélectionnez la catégorie qui vous correspond",
    school: "Étudiant du lycée",
    university: "Étudiant universitaire",
    schoolDesc: "Primaire, collège et lycée",
    universityDesc: "Études universitaires et supérieures",
    next: "Continuer",
  },
  es: {
    title: "¿Cuál es tu nivel de educación?",
    subtitle: "Selecciona la categoría que te aplica",
    school: "Estudiante de escuela",
    university: "Estudiante universitario",
    schoolDesc: "Primaria, secundaria y preparatoria",
    universityDesc: "Estudios universitarios y posgrado",
    next: "Continuar",
  },
};

export function CategorySelection({ onSelect, language }: CategorySelectionProps) {
  const [selected, setSelected] = useState<"school" | "university">("school");
  const t = translations[language as keyof typeof translations] || translations.ar;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-slate-800 border-slate-700 shadow-2xl">
        <div className="p-8">
          <h1 className="text-3xl font-bold text-center text-white mb-2">
            {t.title}
          </h1>
          <p className="text-center text-slate-400 mb-12">
            {t.subtitle}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* School Option */}
            <button
              onClick={() => setSelected("school")}
              className={`p-6 rounded-lg border-2 transition-all ${
                selected === "school"
                  ? "border-blue-500 bg-blue-500/10"
                  : "border-slate-600 bg-slate-700/50 hover:border-slate-500"
              }`}
            >
              <div className="flex justify-center mb-4">
                <div className="bg-gradient-to-br from-blue-400 to-blue-600 p-4 rounded-full">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {t.school}
              </h3>
              <p className="text-sm text-slate-400">
                {t.schoolDesc}
              </p>
            </button>

            {/* University Option */}
            <button
              onClick={() => setSelected("university")}
              className={`p-6 rounded-lg border-2 transition-all ${
                selected === "university"
                  ? "border-purple-500 bg-purple-500/10"
                  : "border-slate-600 bg-slate-700/50 hover:border-slate-500"
              }`}
            >
              <div className="flex justify-center mb-4">
                <div className="bg-gradient-to-br from-purple-400 to-purple-600 p-4 rounded-full">
                  <GraduationCap className="w-8 h-8 text-white" />
                </div>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {t.university}
              </h3>
              <p className="text-sm text-slate-400">
                {t.universityDesc}
              </p>
            </button>
          </div>

          <Button
            onClick={() => onSelect(selected)}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-2 rounded-lg transition-all"
          >
            {t.next}
          </Button>
        </div>
      </Card>
    </div>
  );
}
