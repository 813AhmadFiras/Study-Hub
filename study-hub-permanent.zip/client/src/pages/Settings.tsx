import { useTranslation } from "react-i18next";
import { useTheme } from "@/contexts/ThemeContext";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { Moon, Sun, Monitor, Languages, User, CreditCard } from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const { t, i18n } = useTranslation();
  const { theme, setTheme } = useTheme();
  const { user } = useAuth();

  const handleLanguageChange = (value: string) => {
    i18n.changeLanguage(value);
    toast.success(t('settings.save'));
  };

  const handleThemeChange = (value: string) => {
    setTheme(value as any);
    toast.success(t('settings.save'));
  };

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-8 py-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{t('settings.title')}</h1>
          <p className="text-muted-foreground">
            إدارة تفضيلات حسابك ومظهر التطبيق.
          </p>
        </div>

        <div className="grid gap-6">
          {/* Appearance Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sun className="h-5 w-5" />
                {t('settings.appearance')}
              </CardTitle>
              <CardDescription>
                تخصيص كيفية ظهور التطبيق على جهازك.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Label>{t('settings.theme')}</Label>
                <RadioGroup
                  defaultValue={theme}
                  onValueChange={handleThemeChange}
                  className="grid grid-cols-3 gap-4"
                >
                  <div>
                    <RadioGroupItem value="light" id="light" className="sr-only" />
                    <Label
                      htmlFor="light"
                      className={`flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer ${theme === 'light' ? 'border-primary' : ''}`}
                    >
                      <Sun className="mb-3 h-6 w-6" />
                      {t('settings.light')}
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="dark" id="dark" className="sr-only" />
                    <Label
                      htmlFor="dark"
                      className={`flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer ${theme === 'dark' ? 'border-primary' : ''}`}
                    >
                      <Moon className="mb-3 h-6 w-6" />
                      {t('settings.dark')}
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="system" id="system" className="sr-only" />
                    <Label
                      htmlFor="system"
                      className={`flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer ${theme === 'system' ? 'border-primary' : ''}`}
                    >
                      <Monitor className="mb-3 h-6 w-6" />
                      {t('settings.system')}
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Languages className="h-4 w-4" />
                  {t('settings.language')}
                </Label>
                <Select defaultValue={i18n.language} onValueChange={handleLanguageChange}>
                  <SelectTrigger className="w-full md:w-[200px]">
                    <SelectValue placeholder="اختر اللغة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ar">{t('settings.arabic')}</SelectItem>
                    <SelectItem value="en">{t('settings.english')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Profile Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                {t('settings.profile')}
              </CardTitle>
              <CardDescription>
                معلومات حسابك الشخصية.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="name">{t('settings.name')}</Label>
                <Input id="name" defaultValue={user?.name || ""} disabled />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">{t('settings.email')}</Label>
                <Input id="email" defaultValue={user?.email || ""} disabled />
              </div>
            </CardContent>
          </Card>

          {/* Subscription Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                {t('settings.subscription')}
              </CardTitle>
              <CardDescription>
                إدارة خطة اشتراكك والميزات المتاحة.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium leading-none">
                  {t('settings.plan')}: <span className="text-primary font-bold">{t(`settings.${user?.role === 'admin' ? 'premium' : 'free'}`)}</span>
                </p>
                <p className="text-sm text-muted-foreground">
                  أنت تستخدم النسخة المجانية حالياً.
                </p>
              </div>
              <Button variant="outline">ترقية الخطة</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
