import DashboardLayout from "@/components/DashboardLayout";
import { AdvancedAnalytics } from "@/components/AdvancedAnalytics";
import { SmartNotifications } from "@/components/SmartNotifications";
import { StudyGoals } from "@/components/StudyGoals";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, Bell, Target, TrendingUp } from "lucide-react";
import { InteractiveStudyStats } from "@/components/InteractiveStudyStats";
import { PerformanceHeatmap } from "@/components/PerformanceHeatmap";
import { AIPredictions } from "@/components/AIPredictions";

export default function EnhancedDashboard() {
  const { data: subjects, isLoading: subjectsLoading } = trpc.subjects.list.useQuery();
  const { data: notes, isLoading: notesLoading } = trpc.notes.list.useQuery();
  const { data: flashcards, isLoading: flashcardsLoading } = trpc.flashcards.list.useQuery();
  const { data: pomodoroSessions, isLoading: pomodoroLoading } = trpc.pomodoro.list.useQuery();
  
  const isLoading = subjectsLoading || notesLoading || flashcardsLoading || pomodoroLoading;

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-8">
          <div className="animate-pulse space-y-4">
            <div className="h-12 bg-slate-700 rounded-lg" />
            <div className="grid gap-4 md:grid-cols-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-24 bg-slate-700 rounded-lg" />
              ))}
            </div>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header with Welcome Message */}
        <div className="bg-gradient-to-r from-blue-600/10 to-purple-600/10 rounded-lg p-6 border border-blue-500/20">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            مرحباً بك في لوحة التحكم المتقدمة
          </h1>
          <p className="text-muted-foreground mt-2">
            تابع تقدمك الدراسي وحقق أهدافك مع رؤى ذكية وتحليلات متقدمة
          </p>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="analytics" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">التحليلات</span>
            </TabsTrigger>
            <TabsTrigger value="goals" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              <span className="hidden sm:inline">الأهداف</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">الإشعارات</span>
            </TabsTrigger>
            <TabsTrigger value="insights" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">الرؤى</span>
            </TabsTrigger>
          </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6 mt-6">
            <AdvancedAnalytics 
              pomodoroSessions={pomodoroSessions}
              subjects={subjects}
            />
          </TabsContent>

          {/* Goals Tab */}
          <TabsContent value="goals" className="space-y-6 mt-6">
            <StudyGoals />
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6 mt-6">
            <SmartNotifications />
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6 mt-6">
            <AIPredictions />
            <InteractiveStudyStats />
            <PerformanceHeatmap />
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
                <CardHeader>
                  <CardTitle>📊 تحليل الأداء</CardTitle>
                  <CardDescription>نظرة عامة على أدائك الأكاديمي</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">متوسط درجاتك</p>
                    <p className="text-2xl font-bold text-blue-400">87.5%</p>
                    <p className="text-xs text-muted-foreground">تحسن بمقدار 5% عن الشهر الماضي</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">أفضل مادة</p>
                    <p className="text-lg font-semibold">الرياضيات (92%)</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">تحتاج تحسين</p>
                    <p className="text-lg font-semibold">اللغة الإنجليزية (78%)</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/20">
                <CardHeader>
                  <CardTitle>🎯 توصيات مخصصة</CardTitle>
                  <CardDescription>نصائح لتحسين أدائك</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <p className="font-medium text-green-400">✓ استمر في التقدم</p>
                    <p className="text-xs text-muted-foreground mt-1">أنت على الطريق الصحيح، حافظ على الزخم</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium text-yellow-400">⚠ ركز على الضعيفة</p>
                    <p className="text-xs text-muted-foreground mt-1">خصص وقتاً إضافياً لمادة اللغة الإنجليزية</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium text-blue-400">💡 جرب تقنية جديدة</p>
                    <p className="text-xs text-muted-foreground mt-1">استخدم جلسات بومودورو بفترات 45 دقيقة</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
                <CardHeader>
                  <CardTitle>📈 إحصائيات الأسبوع</CardTitle>
                  <CardDescription>ملخص نشاطك هذا الأسبوع</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">ساعات الدراسة</span>
                    <span className="font-bold">42.5 ساعة</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">جلسات بومودورو</span>
                    <span className="font-bold">34 جلسة</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">ملاحظات مكتملة</span>
                    <span className="font-bold">12 ملاحظة</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">بطاقات مراجعة</span>
                    <span className="font-bold">156 بطاقة</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/20">
                <CardHeader>
                  <CardTitle>🏆 الإنجازات</CardTitle>
                  <CardDescription>الإنجازات التي حققتها</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">🥇</span>
                    <span className="text-sm">الدارس المثابر</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">⭐</span>
                    <span className="text-sm">الطالب المنظم</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">🔥</span>
                    <span className="text-sm">سيد التركيز</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="hover:shadow-lg transition-all">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-blue-400">{subjects?.length || 0}</p>
                <p className="text-sm text-muted-foreground mt-2">مادة دراسية</p>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:shadow-lg transition-all">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-green-400">{notes?.length || 0}</p>
                <p className="text-sm text-muted-foreground mt-2">ملاحظة</p>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:shadow-lg transition-all">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-400">{flashcards?.length || 0}</p>
                <p className="text-sm text-muted-foreground mt-2">بطاقة تعليمية</p>
              </div>
            </CardContent>
          </Card>
          <Card className="hover:shadow-lg transition-all">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-orange-400">{pomodoroSessions?.length || 0}</p>
                <p className="text-sm text-muted-foreground mt-2">جلسة بومودورو</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
