import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Search as SearchIcon, FileText, CreditCard, File, Calculator, Filter } from "lucide-react";
import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState<number | undefined>();
  const [selectedType, setSelectedType] = useState<"all" | "notes" | "flashcards" | "files" | "problems">("all");
  const [hasSearched, setHasSearched] = useState(false);

  const { data: subjects } = trpc.subjects.list.useQuery();
  
  const { data: results, isLoading, refetch } = trpc.search.all.useQuery(
    {
      query: searchQuery,
      subjectId: selectedSubject,
      type: selectedType,
    },
    {
      enabled: false, // لن يتم التشغيل تلقائياً
    }
  );

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setHasSearched(true);
      refetch();
    }
  };

  const totalResults = results
    ? results.notes.length + results.flashcards.length + results.files.length + results.problems.length
    : 0;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">البحث الشامل</h1>
          <p className="text-muted-foreground mt-1">ابحث في جميع ملاحظاتك وبطاقاتك وملفاتك</p>
        </div>

        {/* Search Bar */}
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="ابحث عن أي شيء..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="flex-1"
                />
                <Button onClick={handleSearch} disabled={!searchQuery.trim() || isLoading} className="gap-2">
                  <SearchIcon className="h-4 w-4" />
                  بحث
                </Button>
              </div>

              {/* Filters */}
              <div className="flex gap-2 flex-wrap items-center">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">فلترة:</span>
                
                <Select
                  value={selectedType}
                  onValueChange={(value: any) => setSelectedType(value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="نوع المحتوى" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">الكل</SelectItem>
                    <SelectItem value="notes">الملاحظات</SelectItem>
                    <SelectItem value="flashcards">البطاقات التعليمية</SelectItem>
                    <SelectItem value="files">الملفات</SelectItem>
                    <SelectItem value="problems">المسائل المحلولة</SelectItem>
                  </SelectContent>
                </Select>

                <Select
                  value={selectedSubject?.toString() || "all"}
                  onValueChange={(value) => setSelectedSubject(value === "all" ? undefined : parseInt(value))}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="المادة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع المواد</SelectItem>
                    {subjects?.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id.toString()}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {hasSearched && (
          <div className="space-y-4">
            {isLoading ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">جاري البحث...</p>
                </CardContent>
              </Card>
            ) : totalResults === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <SearchIcon className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">لم يتم العثور على نتائج</p>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">النتائج ({totalResults})</h2>
                </div>

                {/* Notes Results */}
                {results && results.notes.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      الملاحظات ({results.notes.length})
                    </h3>
                    {results.notes.map((note) => {
                      const subject = subjects?.find((s) => s.id === note.subjectId);
                      return (
                        <Card key={note.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-base">{note.title}</CardTitle>
                                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                                  {note.content}
                                </p>
                              </div>
                              {subject && (
                                <Badge
                                  style={{
                                    backgroundColor: subject.color || "#3b82f6",
                                    color: "white",
                                  }}
                                >
                                  {subject.name}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {formatDistanceToNow(new Date(note.createdAt), { addSuffix: true, locale: ar })}
                            </p>
                          </CardHeader>
                        </Card>
                      );
                    })}
                  </div>
                )}

                {/* Flashcards Results */}
                {results && results.flashcards.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      البطاقات التعليمية ({results.flashcards.length})
                    </h3>
                    {results.flashcards.map((card) => {
                      const subject = subjects?.find((s) => s.id === card.subjectId);
                      return (
                        <Card key={card.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-base">{card.front}</CardTitle>
                                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                                  {card.back}
                                </p>
                              </div>
                              {subject && (
                                <Badge
                                  style={{
                                    backgroundColor: subject.color || "#3b82f6",
                                    color: "white",
                                  }}
                                >
                                  {subject.name}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {formatDistanceToNow(new Date(card.createdAt), { addSuffix: true, locale: ar })}
                            </p>
                          </CardHeader>
                        </Card>
                      );
                    })}
                  </div>
                )}

                {/* Files Results */}
                {results && results.files.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <File className="h-5 w-5" />
                      الملفات ({results.files.length})
                    </h3>
                    {results.files.map((file) => {
                      const subject = subjects?.find((s) => s.id === file.subjectId);
                      return (
                        <Card key={file.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-base">{file.filename}</CardTitle>
                                <p className="text-sm text-muted-foreground mt-1">
                                  {(file.size / 1024).toFixed(2)} KB
                                </p>
                              </div>
                              {subject && (
                                <Badge
                                  style={{
                                    backgroundColor: subject.color || "#3b82f6",
                                    color: "white",
                                  }}
                                >
                                  {subject.name}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {formatDistanceToNow(new Date(file.createdAt), { addSuffix: true, locale: ar })}
                            </p>
                          </CardHeader>
                        </Card>
                      );
                    })}
                  </div>
                )}

                {/* Problems Results */}
                {results && results.problems.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Calculator className="h-5 w-5" />
                      المسائل المحلولة ({results.problems.length})
                    </h3>
                    {results.problems.map((problem) => {
                      const subject = subjects?.find((s) => s.id === problem.subjectId);
                      return (
                        <Card key={problem.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-base line-clamp-2">{problem.problemText}</CardTitle>
                                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                                  {problem.solution}
                                </p>
                              </div>
                              {subject && (
                                <Badge
                                  style={{
                                    backgroundColor: subject.color || "#3b82f6",
                                    color: "white",
                                  }}
                                >
                                  {subject.name}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              {formatDistanceToNow(new Date(problem.createdAt), { addSuffix: true, locale: ar })}
                            </p>
                          </CardHeader>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
