import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, CreditCard, Trash2, Edit, RotateCw, CheckCircle2, XCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Flashcards() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<any>(null);
  const [reviewMode, setReviewMode] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [formData, setFormData] = useState({
    front: "",
    back: "",
    subjectId: undefined as number | undefined,
    difficulty: "medium" as "easy" | "medium" | "hard",
  });

  const utils = trpc.useUtils();
  const { data: flashcards, isLoading } = trpc.flashcards.list.useQuery();
  const { data: dueCards } = trpc.flashcards.dueForReview.useQuery();
  const { data: subjects } = trpc.subjects.list.useQuery();
  
  const createMutation = trpc.flashcards.create.useMutation({
    onSuccess: () => {
      utils.flashcards.list.invalidate();
      utils.flashcards.dueForReview.invalidate();
      setIsCreateOpen(false);
      resetForm();
      toast.success("تم إضافة البطاقة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إضافة البطاقة");
    },
  });

  const updateMutation = trpc.flashcards.update.useMutation({
    onSuccess: () => {
      utils.flashcards.list.invalidate();
      utils.flashcards.dueForReview.invalidate();
      setEditingCard(null);
      resetForm();
      toast.success("تم تحديث البطاقة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء تحديث البطاقة");
    },
  });

  const deleteMutation = trpc.flashcards.delete.useMutation({
    onSuccess: () => {
      utils.flashcards.list.invalidate();
      utils.flashcards.dueForReview.invalidate();
      toast.success("تم حذف البطاقة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء حذف البطاقة");
    },
  });

  const reviewMutation = trpc.flashcards.review.useMutation({
    onSuccess: () => {
      utils.flashcards.list.invalidate();
      utils.flashcards.dueForReview.invalidate();
    },
  });

  const resetForm = () => {
    setFormData({
      front: "",
      back: "",
      subjectId: undefined,
      difficulty: "medium",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCard) {
      updateMutation.mutate({ id: editingCard.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (card: any) => {
    setEditingCard(card);
    setFormData({
      front: card.front,
      back: card.back,
      subjectId: card.subjectId,
      difficulty: card.difficulty || "medium",
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه البطاقة؟")) {
      deleteMutation.mutate({ id });
    }
  };

  const startReview = () => {
    if (dueCards && dueCards.length > 0) {
      setReviewMode(true);
      setCurrentCardIndex(0);
      setShowAnswer(false);
    } else {
      toast.info("لا توجد بطاقات للمراجعة حالياً");
    }
  };

  const handleReview = (correct: boolean) => {
    if (!dueCards || !dueCards[currentCardIndex]) return;
    
    reviewMutation.mutate({
      id: dueCards[currentCardIndex].id,
      correct,
    });

    if (currentCardIndex < dueCards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
      setShowAnswer(false);
    } else {
      setReviewMode(false);
      setCurrentCardIndex(0);
      setShowAnswer(false);
      toast.success("أحسنت! أكملت جميع البطاقات");
    }
  };

  const difficultyColors = {
    easy: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    hard: "bg-red-100 text-red-800",
  };

  const difficultyLabels = {
    easy: "سهل",
    medium: "متوسط",
    hard: "صعب",
  };

  if (reviewMode && dueCards && dueCards[currentCardIndex]) {
    const card = dueCards[currentCardIndex];
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[80vh]">
          <div className="w-full max-w-2xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">وضع المراجعة</h2>
                <p className="text-muted-foreground">
                  البطاقة {currentCardIndex + 1} من {dueCards.length}
                </p>
              </div>
              <Button variant="outline" onClick={() => setReviewMode(false)}>
                إنهاء المراجعة
              </Button>
            </div>

            <Card className="min-h-[400px] flex flex-col justify-center cursor-pointer" onClick={() => setShowAnswer(!showAnswer)}>
              <CardContent className="text-center p-12">
                <div className="space-y-6">
                  <div className="text-sm text-muted-foreground">
                    {showAnswer ? "الإجابة" : "السؤال"}
                  </div>
                  <div className="text-2xl font-bold">
                    {showAnswer ? card.back : card.front}
                  </div>
                  {!showAnswer && (
                    <p className="text-sm text-muted-foreground">اضغط لإظهار الإجابة</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {showAnswer && (
              <div className="flex gap-4 justify-center">
                <Button
                  size="lg"
                  variant="outline"
                  className="gap-2 text-red-600 hover:text-red-700"
                  onClick={() => handleReview(false)}
                >
                  <XCircle className="h-5 w-5" />
                  خطأ
                </Button>
                <Button
                  size="lg"
                  className="gap-2"
                  onClick={() => handleReview(true)}
                >
                  <CheckCircle2 className="h-5 w-5" />
                  صحيح
                </Button>
              </div>
            )}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">البطاقات التعليمية</h1>
            <p className="text-muted-foreground mt-1">احفظ المعلومات بفعالية باستخدام البطاقات التعليمية</p>
          </div>
          <div className="flex gap-2">
            {dueCards && dueCards.length > 0 && (
              <Button variant="outline" onClick={startReview} className="gap-2">
                <RotateCw className="h-4 w-4" />
                مراجعة ({dueCards.length})
              </Button>
            )}
            <Dialog open={isCreateOpen || !!editingCard} onOpenChange={(open) => {
              if (!open) {
                setIsCreateOpen(false);
                setEditingCard(null);
                resetForm();
              } else {
                setIsCreateOpen(true);
              }
            }}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  إضافة بطاقة
                </Button>
              </DialogTrigger>
              <DialogContent>
                <form onSubmit={handleSubmit}>
                  <DialogHeader>
                    <DialogTitle>{editingCard ? "تعديل البطاقة" : "إضافة بطاقة جديدة"}</DialogTitle>
                    <DialogDescription>
                      {editingCard ? "قم بتعديل محتوى البطاقة" : "أضف بطاقة تعليمية جديدة"}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="front">السؤال / الوجه الأمامي *</Label>
                      <Textarea
                        id="front"
                        value={formData.front}
                        onChange={(e) => setFormData({ ...formData, front: e.target.value })}
                        placeholder="ما هو...؟"
                        rows={3}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="back">الإجابة / الوجه الخلفي *</Label>
                      <Textarea
                        id="back"
                        value={formData.back}
                        onChange={(e) => setFormData({ ...formData, back: e.target.value })}
                        placeholder="الإجابة..."
                        rows={3}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">المادة</Label>
                      <Select
                        value={formData.subjectId?.toString() || "none"}
                        onValueChange={(value) => setFormData({ ...formData, subjectId: value === "none" ? undefined : parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر مادة (اختياري)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">بدون مادة</SelectItem>
                          {subjects?.map((subject) => (
                            <SelectItem key={subject.id} value={subject.id.toString()}>
                              {subject.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="difficulty">مستوى الصعوبة</Label>
                      <Select
                        value={formData.difficulty}
                        onValueChange={(value: any) => setFormData({ ...formData, difficulty: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="easy">سهل</SelectItem>
                          <SelectItem value="medium">متوسط</SelectItem>
                          <SelectItem value="hard">صعب</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsCreateOpen(false);
                        setEditingCard(null);
                        resetForm();
                      }}
                    >
                      إلغاء
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                      {editingCard ? "تحديث" : "إضافة"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats */}
        {flashcards && flashcards.length > 0 && (
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي البطاقات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{flashcards.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">للمراجعة اليوم</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dueCards?.length || 0}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">معدل النجاح</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {flashcards.length > 0
                    ? Math.round(
                        (flashcards.reduce((sum, card) => sum + (card.correctCount || 0), 0) /
                          flashcards.reduce((sum, card) => sum + (card.reviewCount || 1), 0)) *
                          100
                      )
                    : 0}
                  %
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Cards Grid */}
        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-3/4" />
                  <div className="h-4 bg-muted rounded w-full mt-2" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : flashcards && flashcards.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {flashcards.map((card) => {
              const subject = subjects?.find(s => s.id === card.subjectId);
              return (
                <Card key={card.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${difficultyColors[card.difficulty || "medium"]}`}>
                        {difficultyLabels[card.difficulty || "medium"]}
                      </span>
                      {card.reviewCount && card.reviewCount > 0 && (
                        <span className="text-xs text-muted-foreground">
                          {card.correctCount}/{card.reviewCount} ✓
                        </span>
                      )}
                    </div>
                    <CardTitle className="text-base line-clamp-2">{card.front}</CardTitle>
                    <CardDescription className="line-clamp-2">{card.back}</CardDescription>
                    {subject && (
                      <div className="mt-2">
                        <span
                          className="text-xs px-2 py-1 rounded-full text-white"
                          style={{ backgroundColor: subject.color || "#3b82f6" }}
                        >
                          {subject.name}
                        </span>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 gap-2"
                        onClick={() => handleEdit(card)}
                      >
                        <Edit className="h-4 w-4" />
                        تعديل
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDelete(card.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <CreditCard className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">لا توجد بطاقات تعليمية</h3>
              <p className="text-muted-foreground text-center mb-4">
                ابدأ بإضافة بطاقات تعليمية لتحسين حفظك
              </p>
              <Button onClick={() => setIsCreateOpen(true)} className="gap-2">
                <Plus className="h-4 w-4" />
                إضافة بطاقة
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
