import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Mic, Square, Play, Pause, Save, Trash2, Volume2 } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { storagePut } from "../../../server/storage";

export default function VoiceRecorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [transcription, setTranscription] = useState("");
  const [selectedSubject, setSelectedSubject] = useState<number | undefined>();
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const { data: subjects } = trpc.subjects.list.useQuery();
  const transcribeMutation = trpc.transcribe.transcribe.useMutation();

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm',
      });

      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlob(audioBlob);
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start(100); // جمع البيانات كل 100ms
      setIsRecording(true);
      setIsPaused(false);
      setRecordingTime(0);

      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);

      toast.success("بدأ التسجيل");
    } catch (error) {
      console.error("Error starting recording:", error);
      toast.error("فشل بدء التسجيل. تأكد من السماح بالوصول للميكروفون");
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      toast.info("تم إيقاف التسجيل مؤقتاً");
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "paused") {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
      toast.success("تم استئناف التسجيل");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      toast.success("تم إيقاف التسجيل");
    }
  };

  const discardRecording = () => {
    setAudioBlob(null);
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    setAudioUrl(null);
    setTranscription("");
    setRecordingTime(0);
    toast.info("تم حذف التسجيل");
  };

  const transcribeAudio = async () => {
    if (!audioBlob) {
      toast.error("لا يوجد تسجيل صوتي");
      return;
    }

    // التحقق من حجم الملف (16MB max)
    const maxSize = 16 * 1024 * 1024;
    if (audioBlob.size > maxSize) {
      toast.error("حجم الملف كبير جداً (الحد الأقصى 16MB)");
      return;
    }

    setIsTranscribing(true);
    try {
      // تحويل الصوت إلى base64
      const arrayBuffer = await audioBlob.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      let binary = '';
      for (let i = 0; i < uint8Array.length; i++) {
        binary += String.fromCharCode(uint8Array[i]);
      }
      const base64 = btoa(binary);
      
      // استدعاء API للتحويل
      const result = await transcribeMutation.mutateAsync({
        title: `تسجيل ${new Date().toLocaleDateString('ar-SA')}`,
        audioData: base64,
        mimeType: 'audio/webm',
        size: audioBlob.size,
        subjectId: selectedSubject,
      });

      setTranscription(result.transcription);
      toast.success("تم تحويل الصوت إلى نص بنجاح");
    } catch (error: any) {
      console.error("Transcription error:", error);
      toast.error(error.message || "فشل تحويل الصوت إلى نص");
    } finally {
      setIsTranscribing(false);
    }
  };

  const saveRecording = async () => {
    toast.success("تم حفظ التسجيل بنجاح (التسجيل محفوظ بالفعل في قاعدة البيانات)");
    discardRecording();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-4xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold">تسجيل الصوت المباشر</h1>
          <p className="text-muted-foreground mt-1">سجل المحاضرات والملاحظات الصوتية وحولها إلى نص</p>
        </div>

        {/* Recording Controls */}
        <Card>
          <CardHeader>
            <CardTitle>التسجيل</CardTitle>
            <CardDescription>اضغط على زر الميكروفون لبدء التسجيل</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Timer Display */}
            <div className="flex flex-col items-center justify-center py-8">
              <div className="text-6xl font-mono font-bold text-primary mb-4">
                {formatTime(recordingTime)}
              </div>
              {isRecording && (
                <Badge variant={isPaused ? "secondary" : "default"} className="text-sm">
                  {isPaused ? "متوقف مؤقتاً" : "جاري التسجيل..."}
                </Badge>
              )}
            </div>

            {/* Control Buttons */}
            <div className="flex justify-center gap-4 flex-wrap">
              {!isRecording && !audioBlob && (
                <Button
                  size="lg"
                  onClick={startRecording}
                  className="gap-2 h-14 px-8"
                >
                  <Mic className="h-5 w-5" />
                  بدء التسجيل
                </Button>
              )}

              {isRecording && !isPaused && (
                <>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={pauseRecording}
                    className="gap-2 h-14 px-8"
                  >
                    <Pause className="h-5 w-5" />
                    إيقاف مؤقت
                  </Button>
                  <Button
                    size="lg"
                    variant="destructive"
                    onClick={stopRecording}
                    className="gap-2 h-14 px-8"
                  >
                    <Square className="h-5 w-5" />
                    إيقاف
                  </Button>
                </>
              )}

              {isRecording && isPaused && (
                <>
                  <Button
                    size="lg"
                    onClick={resumeRecording}
                    className="gap-2 h-14 px-8"
                  >
                    <Play className="h-5 w-5" />
                    استئناف
                  </Button>
                  <Button
                    size="lg"
                    variant="destructive"
                    onClick={stopRecording}
                    className="gap-2 h-14 px-8"
                  >
                    <Square className="h-5 w-5" />
                    إيقاف
                  </Button>
                </>
              )}
            </div>

            {/* Audio Playback */}
            {audioUrl && (
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                  <Volume2 className="h-5 w-5 text-muted-foreground" />
                  <audio
                    ref={audioRef}
                    src={audioUrl}
                    controls
                    className="flex-1"
                  />
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Button
                    onClick={transcribeAudio}
                    disabled={isTranscribing}
                    className="gap-2"
                  >
                    {isTranscribing ? "جاري التحويل..." : "تحويل إلى نص"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={startRecording}
                    className="gap-2"
                  >
                    <Mic className="h-4 w-4" />
                    تسجيل جديد
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={discardRecording}
                    className="gap-2"
                  >
                    <Trash2 className="h-4 w-4" />
                    حذف
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Transcription Result */}
        {transcription && (
          <Card>
            <CardHeader>
              <CardTitle>النص المحول</CardTitle>
              <CardDescription>يمكنك تعديل النص قبل الحفظ</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={transcription}
                onChange={(e) => setTranscription(e.target.value)}
                rows={10}
                className="font-mono"
                placeholder="سيظهر النص المحول هنا..."
              />

              <div className="flex items-center gap-4 flex-wrap">
                <Select
                  value={selectedSubject?.toString()}
                  onValueChange={(value) => setSelectedSubject(parseInt(value))}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="اختر المادة (اختياري)" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects?.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id.toString()}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  onClick={saveRecording}
                  disabled={isSaving}
                  className="gap-2"
                >
                  <Save className="h-4 w-4" />
                  {isSaving ? "جاري الحفظ..." : "حفظ التسجيل"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>تعليمات الاستخدام</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• اضغط على "بدء التسجيل" للبدء في تسجيل الصوت</li>
              <li>• يمكنك إيقاف التسجيل مؤقتاً واستئنافه في أي وقت</li>
              <li>• بعد الانتهاء، اضغط "إيقاف" لحفظ التسجيل</li>
              <li>• استمع للتسجيل للتأكد من جودته</li>
              <li>• اضغط "تحويل إلى نص" لتحويل الصوت إلى نص مكتوب</li>
              <li>• يمكنك تعديل النص المحول قبل الحفظ</li>
              <li>• اختر المادة الدراسية المرتبطة (اختياري)</li>
              <li>• احفظ التسجيل والنص في قاعدة البيانات</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
