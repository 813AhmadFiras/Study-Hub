import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { trpc } from "@/lib/trpc";
import { Send, Plus, MessageSquare, Trash2, Loader2, Mic, MicOff } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function AIChat() {
  const [message, setMessage] = useState("");
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const [isListening, setIsListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const utils = trpc.useUtils();
  const { data: conversations } = trpc.chat.list.useQuery();
  const { data: currentConversation } = trpc.chat.get.useQuery(
    { id: currentConversationId! as number },
    { enabled: !!currentConversationId }
  );
  
  // Initialize Web Speech API
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'ar-SA'; // Arabic language
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onstart = () => {
        setIsListening(true);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;

          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }

        if (finalTranscript) {
          setMessage((prev) => prev + finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        toast.error(`خطأ في التعرف على الصوت: ${event.error}`);
        setIsListening(false);
      };
    }
  }, []);

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  const createMutation = trpc.chat.create.useMutation({
    onSuccess: (data) => {
      // @ts-ignore
      setCurrentConversationId(data.conversationId);
      utils.chat.list.invalidate();
      utils.chat.get.invalidate();
      setMessage("");
      toast.success("تم إنشاء محادثة جديدة");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إنشاء المحادثة");
    },
  });

  const sendMutation = trpc.chat.send.useMutation({
    onSuccess: () => {
      utils.chat.get.invalidate({ id: currentConversationId! });
      setMessage("");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إرسال الرسالة");
    },
  });

  const deleteMutation = trpc.chat.delete.useMutation({
    onSuccess: () => {
      setCurrentConversationId(null);
      utils.chat.list.invalidate();
      toast.success("تم حذف المحادثة");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء حذف المحادثة");
    },
  });

  const handleSendMessage = async () => {
    // منع إرسال الرسائل قبل إنشاء محادثة
    if (!message.trim()) {
      toast.error("الرجاء كتابة رسالة");
      return;
    }

    if (!currentConversationId) {
      toast.error("الرجاء إنشاء محادثة أولاً");
      return;
    }

    sendMutation.mutate({
      conversationId: currentConversationId,
      message: message.trim(),
    });
  };

  const handleCreateConversation = () => {
    createMutation.mutate({ message: 'محادثة جديدة' });
  };

  const handleDeleteConversation = (id: number) => {
    if (confirm("هل تريد حذف هذه المحادثة؟")) {
      deleteMutation.mutate({ id });
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [currentConversation?.messages]);

  return (
    <div className="flex gap-4 h-screen bg-gray-50 p-4">
      {/* Sidebar - Conversations */}
      <div className="w-64 flex flex-col bg-white rounded-lg shadow">
        <div className="p-4 border-b">
          <Button
            onClick={handleCreateConversation}
            disabled={createMutation.isPending}
            className="w-full gap-2"
          >
            <Plus className="h-4 w-4" />
            محادثة جديدة
          </Button>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-2">
            {conversations?.map((conv) => (
              <div
                key={conv.id}
                onClick={() => setCurrentConversationId(conv.id)}
                className={`p-3 rounded cursor-pointer transition-colors ${
                  currentConversationId === conv.id
                    ? "bg-blue-100 border-l-4 border-blue-500"
                    : "hover:bg-gray-100"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">
                      {conv.title || "محادثة بدون عنوان"}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(conv.createdAt), {
                        locale: ar,
                        addSuffix: true,
                      })}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteConversation(conv.id);
                    }}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-white rounded-lg shadow">
        {currentConversationId ? (
          <>
            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {currentConversation?.messages?.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-96 text-center">
                    <MessageSquare className="h-12 w-12 text-gray-300 mb-2" />
                    <p className="text-gray-500">ابدأ محادثة جديدة</p>
                  </div>
                ) : (
                  currentConversation?.messages?.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${
                        msg.role === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <Card
                        className={`max-w-xs ${
                          msg.role === "user"
                            ? "bg-blue-500 text-white"
                            : "bg-gray-100"
                        }`}
                      >
                        <CardContent className="p-3">
                          {msg.role === "user" ? (
                            <p className="text-sm">{msg.content}</p>
                          ) : (
                            <Streamdown>{msg.content}</Streamdown>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                  ))
                )}
                <div ref={scrollRef} />
              </div>
            </ScrollArea>

            {/* Input Area */}
            <div className="p-4 border-t space-y-3">
              <div className="flex gap-2">
                <Input
                  placeholder="اكتب سؤالك هنا..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  disabled={sendMutation.isPending}
                />
                <Button
                  onClick={isListening ? stopListening : startListening}
                  variant={isListening ? "destructive" : "outline"}
                  size="icon"
                  title={isListening ? "إيقاف الاستماع" : "بدء الاستماع"}
                >
                  {isListening ? (
                    <Mic className="h-4 w-4 animate-pulse" />
                  ) : (
                    <MicOff className="h-4 w-4" />
                  )}
                </Button>
                <Button
                  onClick={handleSendMessage}
                  disabled={sendMutation.isPending || !message.trim()}
                  size="icon"
                >
                  {sendMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
              <p className="text-xs text-gray-500">
                💡 اضغط على الميكروفون لتحويل صوتك إلى نص (يدعم اللغة العربية)
              </p>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <MessageSquare className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">اختر محادثة أو أنشئ واحدة جديدة</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
