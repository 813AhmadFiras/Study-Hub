import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import {
  Send,
  Plus,
  MessageSquare,
  Trash2,
  Loader2,
  Mic,
  MicOff,
  X,
  FileUp,
  Type,
  BookOpen,
  ArrowRight,
} from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { PlanBanner } from "@/components/PlanBanner";
import { usePlan } from "@/_core/hooks/usePlan";
import { useTranslation } from "react-i18next";
import { enUS, arSA } from "date-fns/locale";

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface ChatSource {
  id: string;
  type: "file" | "text" | "note";
  title: string;
  preview: string;
}

export function EnhancedAIChat() {
  const { t, i18n } = useTranslation();
  const [message, setMessage] = useState("");
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [sources, setSources] = useState<ChatSource[]>([]);
  const [showSourcePanel, setShowSourcePanel] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const { isPremium } = usePlan();
  const dateLocale = i18n.language === 'ar' ? arSA : enUS;

  const utils = trpc.useUtils();
  const { data: conversations } = trpc.chat.list.useQuery();
  const { data: currentConversation } = trpc.chat.get.useQuery(
    { id: currentConversationId! as number },
    { enabled: !!currentConversationId }
  );

  // Initialize Web Speech API
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition && isPremium) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = "ar-SA";
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onstart = () => {
        setIsListening(true);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onresult = (event: any) => {
        let transcript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setMessage((prev) => prev + " " + transcript);
      };
    }
  }, [isPremium]);

  const createConversationMutation = trpc.chat.create.useMutation();
  const sendMessageMutation = trpc.chat.send.useMutation();
  const deleteConversationMutation = trpc.chat.delete.useMutation();

  const handleCreateConversation = async () => {
    try {
      const result = await createConversationMutation.mutateAsync({
        message: "محادثة جديدة",
      });
      setCurrentConversationId((result as any).id || (result as any).insertId);
      utils.chat.list.invalidate();
    } catch (error) {
      toast.error("فشل إنشاء محادثة جديدة");
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim() || !currentConversationId) {
      toast.error("يرجى إنشاء محادثة أولاً أو كتابة رسالة");
      return;
    }

    try {
      await sendMessageMutation.mutateAsync({
        conversationId: currentConversationId,
        message: message.trim(),
      });
      setMessage("");
      setSources([]);
      utils.chat.get.invalidate({ id: currentConversationId });
    } catch (error) {
      toast.error("فشل إرسال الرسالة");
    }
  };

  const handleDeleteConversation = async (id: number) => {
    try {
      await deleteConversationMutation.mutateAsync({ id });
      if (currentConversationId === id) {
        setCurrentConversationId(null);
      }
      utils.chat.list.invalidate();
    } catch (error) {
      toast.error("فشل حذف المحادثة");
    }
  };

  const toggleVoiceInput = () => {
    if (!isPremium) {
      toast.error("ميزة الصوت متاحة فقط في الخطة المتميزة");
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      recognitionRef.current?.start();
    }
  };

  const addSource = (type: "file" | "text" | "note", title: string, preview: string) => {
    setSources([
      ...sources,
      {
        id: Date.now().toString(),
        type,
        title,
        preview,
      },
    ]);
    setShowSourcePanel(false);
  };

  const removeSource = (id: string) => {
    setSources(sources.filter((s) => s.id !== id));
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [currentConversation?.messages]);

  return (
    <div className="h-full flex gap-4 p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Sidebar - قائمة المحادثات */}
      <div className="w-64 flex flex-col gap-4">
        <Button
          onClick={handleCreateConversation}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          {t('nav.chat')}
        </Button>

        <ScrollArea className="flex-1 rounded-lg border border-slate-700 bg-slate-800/50">
          <div className="p-4 space-y-2">
            {conversations?.map((conv) => (
              <div
                key={conv.id}
                className={`p-3 rounded-lg cursor-pointer transition-all ${
                  currentConversationId === conv.id
                    ? "bg-blue-500/20 border border-blue-500/50"
                    : "hover:bg-slate-700/50 border border-transparent"
                }`}
              >
                <div
                  onClick={() => setCurrentConversationId(conv.id)}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <MessageSquare className="w-4 h-4 text-blue-400 flex-shrink-0" />
                    <p className="text-sm text-white truncate">{conv.title}</p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteConversation(conv.id);
                    }}
                    className="p-1 hover:bg-red-500/20 rounded transition-all"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col gap-4">
        <PlanBanner />

        {!currentConversationId ? (
          <Card className="flex-1 bg-slate-800 border-slate-700 flex items-center justify-center">
            <CardContent className="text-center">
              <MessageSquare className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">
                ابدأ محادثة جديدة
              </h2>
              <p className="text-slate-400 mb-6">
                اضغط على "محادثة جديدة" لبدء المحادثة مع المساعد الذكي
              </p>
              <Button
                onClick={handleCreateConversation}
                className="bg-gradient-to-r from-blue-500 to-purple-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                إنشاء محادثة
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Messages Area */}
            <ScrollArea className="flex-1 rounded-lg border border-slate-700 bg-slate-800/50 p-4">
              <div className="space-y-4">
                {currentConversation?.messages?.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${
                      msg.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        msg.role === "user"
                          ? "bg-blue-500/20 border border-blue-500/50 text-white"
                          : "bg-slate-700/50 border border-slate-600 text-slate-100"
                      }`}
                    >
                      {msg.role === "assistant" ? (
                        <Streamdown>{msg.content}</Streamdown>
                      ) : (
                        <p className="text-sm">{msg.content}</p>
                      )}
                      <p className="text-xs text-slate-400 mt-1">
                        {formatDistanceToNow(new Date(msg.timestamp), {
                        locale: dateLocale,
                        addSuffix: true,
                      })}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={scrollRef} />
              </div>
            </ScrollArea>

            {/* Sources Panel */}
            {sources.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    المصادر المستخدمة ({sources.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {sources.map((source) => (
                      <div
                        key={source.id}
                        className="flex items-center gap-2 bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2"
                      >
                        <span className="text-sm text-white truncate">
                          {source.title}
                        </span>
                        <button
                          onClick={() => removeSource(source.id)}
                          className="hover:bg-red-500/20 p-1 rounded transition-all"
                        >
                          <X className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Input Area */}
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="pt-4">
                <div className="space-y-3">
                  {/* Add Source Button */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => setShowSourcePanel(!showSourcePanel)}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 hover:bg-slate-700/50"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      أضف مصدر
                    </Button>
                    {sources.length > 0 && (
                      <span className="text-xs text-slate-400 flex items-center">
                        {sources.length} مصدر مضاف
                      </span>
                    )}
                  </div>

                  {/* Source Options Panel */}
                  {showSourcePanel && (
                    <div className="grid grid-cols-3 gap-2 p-2 bg-slate-700/30 rounded-lg">
                      <button
                        onClick={() =>
                          addSource(
                            "file",
                            "ملف PDF",
                            "تم إضافة ملف PDF للمحادثة"
                          )
                        }
                        className="flex flex-col items-center gap-1 p-2 hover:bg-slate-600/50 rounded transition-all"
                      >
                        <FileUp className="w-5 h-5 text-blue-400" />
                        <span className="text-xs">ملف</span>
                      </button>
                      <button
                        onClick={() =>
                          addSource("text", "نص مباشر", "تم إضافة نص للمحادثة")
                        }
                        className="flex flex-col items-center gap-1 p-2 hover:bg-slate-600/50 rounded transition-all"
                      >
                        <Type className="w-5 h-5 text-purple-400" />
                        <span className="text-xs">نص</span>
                      </button>
                      <button
                        onClick={() =>
                          addSource(
                            "note",
                            "ملاحظة",
                            "تم إضافة ملاحظة للمحادثة"
                          )
                        }
                        className="flex flex-col items-center gap-1 p-2 hover:bg-slate-600/50 rounded transition-all"
                      >
                        <BookOpen className="w-5 h-5 text-green-400" />
                        <span className="text-xs">ملاحظة</span>
                      </button>
                    </div>
                  )}

                  {/* Message Input */}
                  <div className="flex gap-2">
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder={t('nav.chat') + "..."}
                      className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-500"
                    />
                    <Button
                      onClick={toggleVoiceInput}
                      variant="outline"
                      size="icon"
                      className={`border-slate-600 ${
                        isListening
                          ? "bg-red-500/20 border-red-500/50"
                          : "hover:bg-slate-700/50"
                      }`}
                      disabled={!isPremium}
                    >
                      {isListening ? (
                        <MicOff className="w-4 h-4 text-red-400" />
                      ) : (
                        <Mic className="w-4 h-4 text-blue-400" />
                      )}
                    </Button>
                    <Button
                      onClick={handleSendMessage}
                      disabled={
                        sendMessageMutation.isPending || !message.trim()
                      }
                      className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                    >
                      {sendMessageMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
