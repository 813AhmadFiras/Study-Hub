import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Upload, Download, Trash2, File, FileText, Image, Music, Video, Folder } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function Files() {
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const { data: files, isLoading } = trpc.files.list.useQuery();
  const deleteFileMutation = trpc.files.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف الملف بنجاح");
    },
    onError: () => {
      toast.error("فشل حذف الملف");
    },
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      // محاكاة رفع الملف
      toast.success(`تم رفع الملف: ${file.name}`);
      setIsUploading(false);
    } catch (error) {
      toast.error("فشل رفع الملف");
      setIsUploading(false);
    }
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) return <Image className="h-5 w-5" />;
    if (mimeType.startsWith("audio/")) return <Music className="h-5 w-5" />;
    if (mimeType.startsWith("video/")) return <Video className="h-5 w-5" />;
    if (mimeType.includes("pdf")) return <FileText className="h-5 w-5" />;
    return <File className="h-5 w-5" />;
  };

  const filteredFiles = selectedFolder
    ? files?.filter((f) => f.folder === selectedFolder)
    : files || [];

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-6xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold">الملفات الدراسية</h1>
          <p className="text-muted-foreground mt-1">
            نظم ملفاتك الدراسية (PDF، صور، مستندات، وغيرها)
          </p>
        </div>

        {/* Upload Section */}
        <Card>
          <CardHeader>
            <CardTitle>رفع ملف جديد</CardTitle>
            <CardDescription>
              اختر ملفاً من جهازك لرفعه (PDF، صور، مستندات، إلخ)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <label className="flex-1">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="hidden"
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.txt,.mp3,.wav"
                />
                <Button
                  asChild
                  disabled={isUploading}
                  className="w-full gap-2 cursor-pointer"
                >
                  <span>
                    <Upload className="h-4 w-4" />
                    {isUploading ? "جاري الرفع..." : "اختر ملفاً"}
                  </span>
                </Button>
              </label>
            </div>
          </CardContent>
        </Card>

        {/* Folders Section - Placeholder */}
        <Card>
          <CardHeader>
            <CardTitle>تنظيم الملفات</CardTitle>
            <CardDescription>يمكنك تنظيم ملفاتك حسب المادة الدراسية</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              الملفات يتم تنظيمها تلقائياً حسب المادة الدراسية المرتبطة بها
            </p>
          </CardContent>
        </Card>

        {/* Files List */}
        <Card>
          <CardHeader>
            <CardTitle>الملفات</CardTitle>
            <CardDescription>
              {selectedFolder
                ? "ملفات المجلد المختار"
                : "جميع ملفاتك الدراسية"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                جاري تحميل الملفات...
              </div>
            ) : filteredFiles && filteredFiles.length > 0 ? (
              <div className="space-y-2">
                {filteredFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover:bg-accent transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="text-muted-foreground">
                        {getFileIcon(file.mimeType)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{file.filename}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                          <span>
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </span>
                          <span>•</span>
                          <span>
                            {formatDistanceToNow(new Date(file.createdAt), {
                              locale: ar,
                              addSuffix: true,
                            })}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {file.url && (
                        <a href={file.url} target="_blank" rel="noopener noreferrer">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="gap-2"
                          >
                            <Download className="h-4 w-4" />
                            تحميل
                          </Button>
                        </a>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteFileMutation.mutate({ id: file.id })}
                        disabled={deleteFileMutation.isPending}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                لا توجد ملفات حتى الآن. ابدأ برفع ملف جديد!
              </div>
            )}
          </CardContent>
        </Card>

        {/* File Types Info */}
        <Card>
          <CardHeader>
            <CardTitle>أنواع الملفات المدعومة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[
                { type: "PDF", icon: FileText },
                { type: "الصور", icon: Image },
                { type: "الصوت", icon: Music },
                { type: "الفيديو", icon: Video },
                { type: "المستندات", icon: File },
              ].map((item) => (
                <div key={item.type} className="text-center">
                  <item.icon className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm font-medium">{item.type}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
