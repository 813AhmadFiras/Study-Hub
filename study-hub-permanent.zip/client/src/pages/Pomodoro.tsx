import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Timer, Play, Pause, RotateCw, Coffee, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

type SessionType = "work" | "shortBreak" | "longBreak";

export default function Pomodoro() {
  const [sessionType, setSessionType] = useState<SessionType>("work");
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | undefined>();
  const [workDuration, setWorkDuration] = useState(25);
  const [shortBreakDuration, setShortBreakDuration] = useState(5);
  const [longBreakDuration, setLongBreakDuration] = useState(15);
  const [timeLeft, setTimeLeft] = useState(workDuration * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const { data: subjects } = trpc.subjects.list.useQuery();
  const { data: recentSessions } = trpc.pomodoro.recent.useQuery();
  
  const createMutation = trpc.pomodoro.create.useMutation({
    onSuccess: (data) => {
      // @ts-ignore
      setCurrentSessionId(data[0]?.insertId || null);
    },
  });

  const completeMutation = trpc.pomodoro.complete.useMutation({
    onSuccess: () => {
      utils.pomodoro.recent.invalidate();
      setCurrentSessionId(null);
    },
  });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      handleSessionComplete();
    }

    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  const handleStart = () => {
    if (!isRunning && !currentSessionId) {
      const duration = getDuration(sessionType);
      createMutation.mutate({
        duration,
        type: sessionType,
        subjectId: selectedSubjectId,
        startedAt: new Date(),
      });
    }
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(getDuration(sessionType) * 60);
    setCurrentSessionId(null);
  };

  const handleSessionComplete = () => {
    setIsRunning(false);
    
    if (currentSessionId) {
      completeMutation.mutate({ id: currentSessionId });
    }

    // إشعار بانتهاء الجلسة
    if (sessionType === "work") {
      toast.success("أحسنت! أكملت جلسة عمل");
      // الانتقال تلقائياً للاستراحة
      setSessionType("shortBreak");
      setTimeLeft(shortBreakDuration * 60);
    } else {
      toast.success("انتهت فترة الاستراحة");
      setSessionType("work");
      setTimeLeft(workDuration * 60);
    }
    
    setCurrentSessionId(null);
  };

  const getDuration = (type: SessionType) => {
    switch (type) {
      case "work":
        return workDuration;
      case "shortBreak":
        return shortBreakDuration;
      case "longBreak":
        return longBreakDuration;
    }
  };

  const changeSessionType = (type: SessionType) => {
    if (isRunning) {
      toast.error("يجب إيقاف المؤقت أولاً");
      return;
    }
    setSessionType(type);
    setTimeLeft(getDuration(type) * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const sessionTypeLabels = {
    work: "جلسة عمل",
    shortBreak: "استراحة قصيرة",
    longBreak: "استراحة طويلة",
  };

  const sessionTypeColors = {
    work: "from-blue-500 to-indigo-600",
    shortBreak: "from-green-500 to-emerald-600",
    longBreak: "from-purple-500 to-violet-600",
  };

  const progress = ((getDuration(sessionType) * 60 - timeLeft) / (getDuration(sessionType) * 60)) * 100;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">مؤقت بومودورو</h1>
          <p className="text-muted-foreground mt-1">نظم وقتك وحسّن تركيزك</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Timer Section */}
          <div className="lg:col-span-2 space-y-6" style={{backgroundColor: '#ffffff'}}>
            {/* Session Type Selector */}
            <div className="flex gap-2 justify-center">
              <Button
                variant={sessionType === "work" ? "default" : "outline"}
                onClick={() => changeSessionType("work")}
                className="gap-2" style={{backgroundColor: '#ffffff', color: '#000000'}}
              >
                <Timer className="h-4 w-4" />
                عمل
              </Button>
              <Button
                variant={sessionType === "shortBreak" ? "default" : "outline"}
                onClick={() => changeSessionType("shortBreak")}
                className="gap-2" style={{color: '#000000'}}
              >
                <Coffee className="h-4 w-4" />
                استراحة قصيرة
              </Button>
              <Button
                variant={sessionType === "longBreak" ? "default" : "outline"}
                onClick={() => changeSessionType("longBreak")}
                className="gap-2" style={{color: '#000000', backgroundColor: '#ffffff'}}
              >
                <Clock className="h-4 w-4" />
                استراحة طويلة
              </Button>
            </div>

            {/* Timer Display */}
            <Card className={`bg-gradient-to-br ${sessionTypeColors[sessionType]} text-white`}>
              <CardContent className="p-12">
                <div className="text-center space-y-6">
                  <h2 className="text-2xl font-bold">{sessionTypeLabels[sessionType]}</h2>
                  <div className="text-8xl font-bold font-mono">{formatTime(timeLeft)}</div>
                  
                  {/* Progress Bar */}
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div
                      className="bg-white h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${progress}%` }}
                    />
                  </div>

                  {/* Controls */}
                  <div className="flex gap-4 justify-center pt-4">
                    {!isRunning ? (
                      <Button
                        size="lg"
                        variant="secondary"
                        onClick={handleStart}
                        className="gap-2 text-lg px-8" style={{color: '#000000'}}
                      >
                        <Play className="h-6 w-6" />
                        بدء
                      </Button>
                    ) : (
                      <Button
                        size="lg"
                        variant="secondary"
                        onClick={handlePause}
                        className="gap-2 text-lg px-8"
                      >
                        <Pause className="h-6 w-6" />
                        إيقاف مؤقت
                      </Button>
                    )}
                    <Button
                      size="lg"
                      variant="secondary"
                      onClick={handleReset}
                      className="gap-2" style={{color: '#000000'}}
                    >
                      <RotateCw className="h-5 w-5" />
                      إعادة تعيين
                    </Button>
                  </div>

                  {/* Subject Selector */}
                  {sessionType === "work" && (
                    <div className="max-w-xs mx-auto">
                      <Select
                        value={selectedSubjectId?.toString() || "none"}
                        onValueChange={(value) => setSelectedSubjectId(value === "none" ? undefined : parseInt(value))}
                        disabled={isRunning}
                      >
                        <SelectTrigger className="bg-white/20 border-white/30 text-white" style={{color: '#000000'}}>
                          <SelectValue placeholder="اختر مادة (اختياري)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">بدون مادة</SelectItem>
                          {subjects?.map((subject) => (
                            <SelectItem key={subject.id} value={subject.id.toString()}>
                              {subject.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Settings */}
            <Card>
              <CardHeader>
                <CardTitle>الإعدادات</CardTitle>
                <CardDescription>خصص مدة الجلسات حسب احتياجك</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{color: '#000000'}}>جلسة العمل (دقيقة)</label>
                    <Select
                      value={workDuration.toString()}
                      onValueChange={(value) => {
                        setWorkDuration(parseInt(value));
                        if (sessionType === "work" && !isRunning) {
                          setTimeLeft(parseInt(value) * 60);
                        }
                      }}
                      disabled={isRunning}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15</SelectItem>
                        <SelectItem value="20">20</SelectItem>
                        <SelectItem value="25">25</SelectItem>
                        <SelectItem value="30">30</SelectItem>
                        <SelectItem value="45">45</SelectItem>
                        <SelectItem value="60">60</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{color: '#000000'}}>استراحة قصيرة (دقيقة)</label>
                    <Select
                      value={shortBreakDuration.toString()}
                      onValueChange={(value) => {
                        setShortBreakDuration(parseInt(value));
                        if (sessionType === "shortBreak" && !isRunning) {
                          setTimeLeft(parseInt(value) * 60);
                        }
                      }}
                      disabled={isRunning}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3</SelectItem>
                        <SelectItem value="5">5</SelectItem>
                        <SelectItem value="10">10</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{color: '#000000'}}>استراحة طويلة (دقيقة)</label>
                    <Select
                      value={longBreakDuration.toString()}
                      onValueChange={(value) => {
                        setLongBreakDuration(parseInt(value));
                        if (sessionType === "longBreak" && !isRunning) {
                          setTimeLeft(parseInt(value) * 60);
                        }
                      }}
                      disabled={isRunning}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10</SelectItem>
                        <SelectItem value="15">15</SelectItem>
                        <SelectItem value="20">20</SelectItem>
                        <SelectItem value="30">30</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Sessions */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>الجلسات الأخيرة</CardTitle>
                <CardDescription>آخر 10 جلسات مكتملة</CardDescription>
              </CardHeader>
              <CardContent>
                {recentSessions && recentSessions.length > 0 ? (
                  <div className="space-y-3">
                    {recentSessions.filter(s => s.completed).slice(0, 10).map((session) => {
                      const subject = subjects?.find(s => s.id === session.subjectId);
                      return (
                        <div key={session.id} className="flex items-center justify-between text-sm border-b pb-2">
                          <div className="flex items-center gap-2">
                            {session.type === "work" ? (
                              <Timer className="h-4 w-4 text-blue-600" />
                            ) : (
                              <Coffee className="h-4 w-4 text-green-600" />
                            )}
                            <div>
                              <div className="font-medium">
                                {session.type === "work" ? "عمل" : "استراحة"}
                              </div>
                              {subject && (
                                <div className="text-xs text-muted-foreground">{subject.name}</div>
                              )}
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(session.startedAt), { addSuffix: true, locale: ar })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    لا توجد جلسات مكتملة بعد
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
