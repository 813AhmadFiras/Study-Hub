import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Copy, Check, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function SetupGuidePage() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    toast.success("تم النسخ إلى الحافظة");
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const CodeBlock = ({ code, id }: { code: string; id: string }) => (
    <div className="relative bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto">
      <pre className="text-sm font-mono">{code}</pre>
      <Button
        size="sm"
        variant="ghost"
        className="absolute top-2 right-2 text-slate-400 hover:text-slate-100"
        onClick={() => copyToClipboard(code, id)}
      >
        {copiedCode === id ? (
          <Check className="h-4 w-4" />
        ) : (
          <Copy className="h-4 w-4" />
        )}
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">دليل إعداد Study Hub</h1>
          <p className="text-gray-600">اتبع هذه الخطوات لإعداد التطبيق بشكل كامل</p>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="python">Python</TabsTrigger>
            <TabsTrigger value="api">API Keys</TabsTrigger>
            <TabsTrigger value="run">التشغيل</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>📋 نظرة عامة على الإعداد</CardTitle>
                <CardDescription>المتطلبات والخطوات الأساسية</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    تأكد من تثبيت Python 3.8 أو أحدث على جهازك قبل البدء
                  </AlertDescription>
                </Alert>

                <div className="space-y-3">
                  <h3 className="font-semibold text-lg">المتطلبات:</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-700">
                    <li>Python 3.8 أو أحدث</li>
                    <li>Node.js 16 أو أحدث</li>
                    <li>npm أو yarn أو pnpm</li>
                    <li>مفتاح API من OpenAI (اختياري للميزات المتقدمة)</li>
                    <li>اتصال إنترنت</li>
                  </ul>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold text-lg">خطوات الإعداد:</h3>
                  <ol className="list-decimal list-inside space-y-2 text-gray-700">
                    <li>تثبيت المتطلبات (Python و Node.js)</li>
                    <li>استنساخ المشروع أو تحميله</li>
                    <li>تثبيت الحزم (pip و npm)</li>
                    <li>إعداد متغيرات البيئة</li>
                    <li>تشغيل التطبيق</li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Python Tab */}
          <TabsContent value="python" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>🐍 إعداد Python</CardTitle>
                <CardDescription>تثبيت Python والحزم المطلوبة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Check Python */}
                <div>
                  <h3 className="font-semibold mb-3">1. التحقق من تثبيت Python</h3>
                  <CodeBlock
                    code="python --version\npython3 --version"
                    id="check-python"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    يجب أن تظهر نسخة Python 3.8 أو أحدث
                  </p>
                </div>

                {/* Install Python */}
                <div>
                  <h3 className="font-semibold mb-3">2. تثبيت Python (إذا لم يكن مثبتاً)</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-semibold mb-2">على Windows:</p>
                      <CodeBlock
                        code="# قم بتحميل Python من:\n# https://www.python.org/downloads/\n# ثم قم بتشغيل المثبت"
                        id="install-python-windows"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-semibold mb-2">على macOS:</p>
                      <CodeBlock
                        code="brew install python3"
                        id="install-python-macos"
                      />
                    </div>
                    <div>
                      <p className="text-sm font-semibold mb-2">على Linux:</p>
                      <CodeBlock
                        code="sudo apt-get update\nsudo apt-get install python3 python3-pip"
                        id="install-python-linux"
                      />
                    </div>
                  </div>
                </div>

                {/* Install pip packages */}
                <div>
                  <h3 className="font-semibold mb-3">3. تثبيت الحزم المطلوبة</h3>
                  <CodeBlock
                    code="pip install --upgrade pip\npip install openai\npip install python-dotenv\npip install requests"
                    id="install-packages"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    هذه الحزم مطلوبة للعمل مع OpenAI API والمتغيرات البيئية
                  </p>
                </div>

                {/* Virtual Environment */}
                <div>
                  <h3 className="font-semibold mb-3">4. (اختياري) إنشاء بيئة افتراضية</h3>
                  <CodeBlock
                    code="python -m venv venv\n\n# على Windows:\nvenv\\Scripts\\activate\n\n# على macOS/Linux:\nsource venv/bin/activate"
                    id="virtual-env"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    يُنصح بإنشاء بيئة افتراضية لعزل الحزم
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* API Keys Tab */}
          <TabsContent value="api" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>🔑 إعداد مفاتيح API</CardTitle>
                <CardDescription>الحصول على مفاتيح API المطلوبة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* OpenAI API */}
                <div>
                  <h3 className="font-semibold mb-3">1. الحصول على مفتاح OpenAI API</h3>
                  <ol className="list-decimal list-inside space-y-2 text-gray-700 mb-3">
                    <li>اذهب إلى <a href="https://platform.openai.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">platform.openai.com</a></li>
                    <li>سجل دخولك أو أنشئ حساباً جديداً</li>
                    <li>اذهب إلى صفحة API Keys</li>
                    <li>انقر على "Create new secret key"</li>
                    <li>انسخ المفتاح وحفظه في مكان آمن</li>
                  </ol>
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      ⚠️ لا تشارك مفتاح API الخاص بك مع أحد. احفظه في ملف .env فقط
                    </AlertDescription>
                  </Alert>
                </div>

                {/* .env File */}
                <div>
                  <h3 className="font-semibold mb-3">2. إنشاء ملف .env</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    أنشئ ملف باسم <code className="bg-gray-100 px-2 py-1 rounded">.env</code> في جذر المشروع
                  </p>
                  <CodeBlock
                    code="# OpenAI API Configuration\nOPENAI_API_KEY=your-api-key-here\nOPENAI_MODEL=gpt-4\n\n# Database (إذا كان مطلوباً)\nDATABASE_URL=your-database-url\n\n# Application\nNODE_ENV=development\nPORT=3000"
                    id="env-file"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    استبدل <code className="bg-gray-100 px-2 py-1 rounded">your-api-key-here</code> بمفتاح API الحقيقي
                  </p>
                </div>

                {/* Environment Variables */}
                <div>
                  <h3 className="font-semibold mb-3">3. متغيرات البيئة المتاحة</h3>
                  <div className="bg-gray-50 p-4 rounded-lg space-y-2 text-sm">
                    <div>
                      <p className="font-semibold">OPENAI_API_KEY</p>
                      <p className="text-gray-600">مفتاح API من OpenAI</p>
                    </div>
                    <div>
                      <p className="font-semibold">OPENAI_MODEL</p>
                      <p className="text-gray-600">نموذج OpenAI المستخدم (gpt-4, gpt-3.5-turbo)</p>
                    </div>
                    <div>
                      <p className="font-semibold">NODE_ENV</p>
                      <p className="text-gray-600">بيئة التطوير (development, production)</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Run Tab */}
          <TabsContent value="run" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>🚀 تشغيل التطبيق</CardTitle>
                <CardDescription>خطوات تشغيل Study Hub</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Install Dependencies */}
                <div>
                  <h3 className="font-semibold mb-3">1. تثبيت الحزم</h3>
                  <CodeBlock
                    code="# تثبيت حزم Node.js\npnpm install\n\n# أو باستخدام npm\nnpm install\n\n# أو باستخدام yarn\nyarn install"
                    id="install-deps"
                  />
                </div>

                {/* Development Server */}
                <div>
                  <h3 className="font-semibold mb-3">2. تشغيل خادم التطوير</h3>
                  <CodeBlock
                    code="pnpm dev\n\n# أو\nnpm run dev\n\n# أو\nyarn dev"
                    id="dev-server"
                  />
                  <p className="text-sm text-gray-600 mt-2">
                    سيتم فتح التطبيق على <code className="bg-gray-100 px-2 py-1 rounded">http://localhost:3000</code>
                  </p>
                </div>

                {/* Build for Production */}
                <div>
                  <h3 className="font-semibold mb-3">3. بناء النسخة الإنتاجية</h3>
                  <CodeBlock
                    code="pnpm build\n\n# أو\nnpm run build\n\n# أو\nyarn build"
                    id="build-prod"
                  />
                </div>

                {/* Start Production */}
                <div>
                  <h3 className="font-semibold mb-3">4. تشغيل النسخة الإنتاجية</h3>
                  <CodeBlock
                    code="pnpm start\n\n# أو\nnpm start\n\n# أو\nyarn start"
                    id="start-prod"
                  />
                </div>

                {/* Troubleshooting */}
                <div>
                  <h3 className="font-semibold mb-3">❓ استكشاف الأخطاء</h3>
                  <div className="space-y-3">
                    <div className="bg-yellow-50 border border-yellow-200 p-3 rounded">
                      <p className="font-semibold text-sm">خطأ: "command not found: pnpm"</p>
                      <p className="text-sm text-gray-600 mt-1">
                        استخدم <code className="bg-gray-100 px-2 py-1 rounded">npm</code> أو <code className="bg-gray-100 px-2 py-1 rounded">yarn</code> بدلاً من pnpm
                      </p>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-200 p-3 rounded">
                      <p className="font-semibold text-sm">خطأ: "Port 3000 already in use"</p>
                      <p className="text-sm text-gray-600 mt-1">
                        استخدم منفذ مختلف: <code className="bg-gray-100 px-2 py-1 rounded">PORT=3001 pnpm dev</code>
                      </p>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-200 p-3 rounded">
                      <p className="font-semibold text-sm">خطأ: "OpenAI API key not found"</p>
                      <p className="text-sm text-gray-600 mt-1">
                        تأكد من إنشاء ملف .env وإضافة OPENAI_API_KEY فيه
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-900">💡 نصائح مهمة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-green-900">
                <p>✅ احفظ ملف .env في .gitignore لتجنب مشاركة المفاتيح</p>
                <p>✅ استخدم بيئة افتراضية لعزل الحزم</p>
                <p>✅ تحقق من الاتصال بالإنترنت قبل التشغيل</p>
                <p>✅ اقرأ رسائل الخطأ بعناية للعثور على المشكلة</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
