import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Users, Zap, BarChart3, MessageSquare, FileText, Play } from "lucide-react";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function LandingPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      setLocation("/");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  const features = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: "تنظيم المواد",
      description: "نظم مواداك الدراسية بسهولة مع جداول زمنية ذكية",
    },
    {
      icon: <MessageSquare className="w-6 h-6" />,
      title: "الملاحظات الذكية",
      description: "دون ملاحظاتك مع محرر غني يدعم النصوص والصور",
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "مؤقت بومودورو",
      description: "ادرس بتركيز مع تقنية بومودورو المثبتة",
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "تتبع الإنتاجية",
      description: "راقب تقدمك مع رسوم بيانية تفاعلية وإحصائيات",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "الدراسة الجماعية",
      description: "ادرس مع أصدقائك وشارك الملاحظات والملفات",
    },
    {
      icon: <FileText className="w-6 h-6" />,
      title: "البطاقات التعليمية",
      description: "أنشئ بطاقات ذكية للحفظ الفعال والمراجعة",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      <Navbar />

      {/* Hero Section */}
      <section id="home" className="pt-32 pb-20 px-4 relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute top-20 left-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
        <div className="absolute bottom-0 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl -z-10"></div>

        <div className="max-w-7xl mx-auto">
          {/* Badge */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-full backdrop-blur-sm">
              <span className="text-sm text-blue-400">✨</span>
              <span className="text-sm text-slate-300">
                Join the Future of Collaborative Learning
              </span>
            </div>
          </div>

          {/* Main Heading */}
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="text-slate-300">Study </span>
              <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Together,
              </span>
              <br />
              <span className="bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
                Achieve More
              </span>
            </h1>

            <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-8">
              Join synchronized study sessions with friends. Share notes, chat in real-time, and stay
              motivated with collaborative learning.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handleGetStarted}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-200 text-lg"
              >
                <BookOpen className="w-5 h-5 ml-2" />
                Start Learning Together
              </Button>
              <Button
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-800 font-semibold py-3 px-8 rounded-lg text-lg"
              >
                <Play className="w-5 h-5 ml-2" />
                Watch Demo
              </Button>
            </div>
          </div>

          {/* Hero Image Placeholder */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-2xl blur-2xl"></div>
            <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl border border-slate-700 p-8 md:p-12 backdrop-blur-sm">
              <div className="aspect-video bg-slate-800/50 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <BookOpen className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-500">Study Hub Dashboard Preview</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Powerful Features for Every Student
            </h2>
            <p className="text-xl text-slate-400">
              Everything you need to study smarter, not harder
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => (
              <Card
                key={idx}
                className="bg-slate-800/50 border-slate-700 hover:border-slate-600 transition-all duration-200 hover:shadow-lg hover:shadow-blue-500/10"
              >
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-4 text-white">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-slate-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-slate-700 rounded-2xl p-12 text-center backdrop-blur-sm">
            <h2 className="text-4xl font-bold text-white mb-4">Ready to Transform Your Learning?</h2>
            <p className="text-xl text-slate-400 mb-8">
              Join thousands of students already using StudyHub to achieve their academic goals
            </p>
            <Button
              onClick={handleGetStarted}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-8 rounded-lg text-lg"
            >
              Get Started Free
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">📚</span>
                </div>
                <span className="text-lg font-bold text-white">StudyHub</span>
              </div>
              <p className="text-slate-400 text-sm">
                The ultimate platform for collaborative learning
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Cookies</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8 text-center text-slate-400 text-sm">
            <p>&copy; 2025 StudyHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
