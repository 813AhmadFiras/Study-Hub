import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Upload, Loader2, Copy, Trash2, Save } from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function Solver() {
  const [problemText, setProblemText] = useState("");
  const [problemImage, setProblemImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [solution, setSolution] = useState<string | null>(null);
  const [isSolving, setIsSolving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const solveMutation = trpc.solver.solve.useMutation();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // التحقق من نوع الملف
    if (!file.type.startsWith("image/")) {
      toast.error("يرجى اختيار صورة");
      return;
    }

    setProblemImage(file);

    // عرض معاينة الصورة
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSolve = async () => {
    if (!problemText && !problemImage) {
      toast.error("يرجى إدخال المسألة أو تحميل صورة");
      return;
    }

    setIsSolving(true);
    try {
      let imageUrl: string | undefined;

      // إذا كانت هناك صورة، تحويلها إلى base64
      if (problemImage) {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64 = reader.result as string;
          const result = await solveMutation.mutateAsync({
            problemText: problemText || "حل المسألة الموجودة في الصورة",
            problemImage: base64,
          });
          setSolution(result.solution);
          toast.success("تم حل المسألة بنجاح!");
        };
        reader.readAsDataURL(problemImage);
      } else {
        const result = await solveMutation.mutateAsync({
          problemText,
        });
        setSolution(result.solution);
        toast.success("تم حل المسألة بنجاح!");
      }
    } catch (error: any) {
      console.error("Solver error:", error);
      toast.error(error.message || "فشل حل المسألة");
    } finally {
      setIsSolving(false);
    }
  };

  const copySolution = () => {
    if (solution) {
      navigator.clipboard.writeText(solution);
      toast.success("تم نسخ الحل");
    }
  };

  const clearAll = () => {
    setProblemText("");
    setProblemImage(null);
    setImagePreview(null);
    setSolution(null);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-4xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold">حل المسائل بالذكاء الاصطناعي</h1>
          <p className="text-muted-foreground mt-1">
            اكتب المسألة أو صورها واحصل على حل تفصيلي خطوة بخطوة
          </p>
        </div>

        {/* Input Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Text Input */}
          <Card>
            <CardHeader>
              <CardTitle>إدخال المسألة</CardTitle>
              <CardDescription>اكتب المسألة مباشرة هنا</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={problemText}
                onChange={(e) => setProblemText(e.target.value)}
                placeholder="أدخل المسألة الرياضية أو العلمية هنا..."
                rows={8}
                className="font-mono"
              />
            </CardContent>
          </Card>

          {/* Image Upload */}
          <Card>
            <CardHeader>
              <CardTitle>تحميل صورة</CardTitle>
              <CardDescription>أو صور المسألة من الكتاب</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:bg-accent transition-colors"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                <p className="font-medium">اضغط لتحميل صورة</p>
                <p className="text-xs text-muted-foreground mt-1">
                  أو اسحب الصورة هنا
                </p>
              </div>

              {imagePreview && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">معاينة الصورة:</p>
                  <img
                    src={imagePreview}
                    alt="Problem"
                    className="w-full rounded-lg max-h-[300px] object-contain"
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Solve Button */}
        <div className="flex gap-2 justify-center">
          <Button
            onClick={handleSolve}
            disabled={isSolving || (!problemText && !problemImage)}
            size="lg"
            className="gap-2"
          >
            {isSolving ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                جاري الحل...
              </>
            ) : (
              "حل المسألة"
            )}
          </Button>
          {(problemText || problemImage) && (
            <Button
              onClick={clearAll}
              variant="outline"
              size="lg"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Solution Section */}
        {solution && (
          <Card className="border-primary/50 bg-primary/5">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>الحل التفصيلي</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copySolution}
                    className="gap-2"
                  >
                    <Copy className="h-4 w-4" />
                    نسخ
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <Streamdown>{solution}</Streamdown>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tips */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">نصائح للحصول على أفضل النتائج</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• اكتب المسألة بوضوح وتفصيل كامل</li>
              <li>• إذا كانت الصورة غير واضحة، حاول كتابة المسألة بدلاً منها</li>
              <li>• يمكنك استخدام الرموز الرياضية والعلمية</li>
              <li>• الحل يتم خطوة بخطوة لسهولة الفهم</li>
              <li>• تأكد من صحة الحل قبل الاعتماد عليه</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
