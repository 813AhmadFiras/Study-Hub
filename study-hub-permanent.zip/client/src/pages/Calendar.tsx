import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, Calendar as CalendarIcon, Trash2, Edit, CheckCircle2, Circle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, isBefore, startOfDay } from "date-fns";
import { ar } from "date-fns/locale";

export default function Calendar() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "other" as "exam" | "assignment" | "deadline" | "other",
    eventDate: "",
    eventTime: "",
    location: "",
    reminderBefore: 60,
    subjectId: undefined as number | undefined,
  });

  const utils = trpc.useUtils();
  const { data: events, isLoading } = trpc.events.list.useQuery();
  const { data: subjects } = trpc.subjects.list.useQuery();
  
  const createMutation = trpc.events.create.useMutation({
    onSuccess: () => {
      utils.events.list.invalidate();
      utils.events.upcoming.invalidate();
      setIsCreateOpen(false);
      resetForm();
      toast.success("تم إضافة الحدث بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إضافة الحدث");
    },
  });

  const updateMutation = trpc.events.update.useMutation({
    onSuccess: () => {
      utils.events.list.invalidate();
      utils.events.upcoming.invalidate();
      setEditingEvent(null);
      resetForm();
      toast.success("تم تحديث الحدث بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء تحديث الحدث");
    },
  });

  const deleteMutation = trpc.events.delete.useMutation({
    onSuccess: () => {
      utils.events.list.invalidate();
      utils.events.upcoming.invalidate();
      toast.success("تم حذف الحدث بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء حذف الحدث");
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      type: "other",
      eventDate: "",
      eventTime: "",
      location: "",
      reminderBefore: 60,
      subjectId: undefined,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const eventDateTime = new Date(`${formData.eventDate}T${formData.eventTime}`);
    
    if (editingEvent) {
      updateMutation.mutate({
        id: editingEvent.id,
        title: formData.title,
        description: formData.description,
        type: formData.type,
        eventDate: eventDateTime,
        location: formData.location,
        reminderBefore: formData.reminderBefore,
        subjectId: formData.subjectId,
      });
    } else {
      createMutation.mutate({
        title: formData.title,
        description: formData.description,
        type: formData.type,
        eventDate: eventDateTime,
        location: formData.location,
        reminderBefore: formData.reminderBefore,
        subjectId: formData.subjectId,
      });
    }
  };

  const handleEdit = (event: any) => {
    setEditingEvent(event);
    const eventDate = new Date(event.eventDate);
    setFormData({
      title: event.title,
      description: event.description || "",
      type: event.type,
      eventDate: format(eventDate, "yyyy-MM-dd"),
      eventTime: format(eventDate, "HH:mm"),
      location: event.location || "",
      reminderBefore: event.reminderBefore || 60,
      subjectId: event.subjectId,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا الحدث؟")) {
      deleteMutation.mutate({ id });
    }
  };

  const toggleComplete = (event: any) => {
    updateMutation.mutate({
      id: event.id,
      completed: !event.completed,
    });
  };

  const eventTypeLabels = {
    exam: "امتحان",
    assignment: "واجب",
    deadline: "موعد نهائي",
    other: "آخر",
  };

  const eventTypeColors = {
    exam: "bg-red-100 text-red-800 border-red-200",
    assignment: "bg-blue-100 text-blue-800 border-blue-200",
    deadline: "bg-orange-100 text-orange-800 border-orange-200",
    other: "bg-gray-100 text-gray-800 border-gray-200",
  };

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getEventsForDay = (day: Date) => {
    return events?.filter(event => isSameDay(new Date(event.eventDate), day)) || [];
  };

  const upcomingEvents = events
    ?.filter(e => !e.completed && new Date(e.eventDate) >= startOfDay(new Date()))
    .sort((a, b) => new Date(a.eventDate).getTime() - new Date(b.eventDate).getTime())
    .slice(0, 5);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">التقويم</h1>
            <p className="text-muted-foreground mt-1">نظم مواعيدك وامتحاناتك</p>
          </div>
          <Dialog open={isCreateOpen || !!editingEvent} onOpenChange={(open) => {
            if (!open) {
              setIsCreateOpen(false);
              setEditingEvent(null);
              resetForm();
            } else {
              setIsCreateOpen(true);
            }
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                إضافة حدث
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>{editingEvent ? "تعديل الحدث" : "إضافة حدث جديد"}</DialogTitle>
                  <DialogDescription>
                    {editingEvent ? "قم بتعديل تفاصيل الحدث" : "أضف حدث جديد إلى تقويمك"}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">العنوان *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="عنوان الحدث..."
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">النوع *</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: any) => setFormData({ ...formData, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="exam">امتحان</SelectItem>
                        <SelectItem value="assignment">واجب</SelectItem>
                        <SelectItem value="deadline">موعد نهائي</SelectItem>
                        <SelectItem value="other">آخر</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="eventDate">التاريخ *</Label>
                      <Input
                        id="eventDate"
                        type="date"
                        value={formData.eventDate}
                        onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="eventTime">الوقت *</Label>
                      <Input
                        id="eventTime"
                        type="time"
                        value={formData.eventTime}
                        onChange={(e) => setFormData({ ...formData, eventTime: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">الوصف</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="تفاصيل إضافية..."
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">المكان</Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="مكان الحدث..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">المادة</Label>
                    <Select
                      value={formData.subjectId?.toString() || "none"}
                      onValueChange={(value) => setFormData({ ...formData, subjectId: value === "none" ? undefined : parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر مادة (اختياري)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">بدون مادة</SelectItem>
                        {subjects?.map((subject) => (
                          <SelectItem key={subject.id} value={subject.id.toString()}>
                            {subject.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="reminder">التذكير قبل</Label>
                    <Select
                      value={formData.reminderBefore.toString()}
                      onValueChange={(value) => setFormData({ ...formData, reminderBefore: parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 دقيقة</SelectItem>
                        <SelectItem value="30">30 دقيقة</SelectItem>
                        <SelectItem value="60">ساعة واحدة</SelectItem>
                        <SelectItem value="1440">يوم واحد</SelectItem>
                        <SelectItem value="10080">أسبوع واحد</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsCreateOpen(false);
                      setEditingEvent(null);
                      resetForm();
                    }}
                  >
                    إلغاء
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                    {editingEvent ? "تحديث" : "إضافة"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Calendar View */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{format(selectedDate, "MMMM yyyy", { locale: ar })}</CardTitle>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedDate(new Date(selectedDate.setMonth(selectedDate.getMonth() - 1)))}
                    >
                      السابق
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedDate(new Date())}
                    >
                      اليوم
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedDate(new Date(selectedDate.setMonth(selectedDate.getMonth() + 1)))}
                    >
                      التالي
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-2">
                  {["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"].map((day) => (
                    <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                      {day}
                    </div>
                  ))}
                  {daysInMonth.map((day) => {
                    const dayEvents = getEventsForDay(day);
                    const isCurrentDay = isToday(day);
                    return (
                      <div
                        key={day.toString()}
                        className={`min-h-[80px] p-2 border rounded-lg ${
                          isCurrentDay ? "bg-primary/10 border-primary" : "hover:bg-accent"
                        }`}
                      >
                        <div className={`text-sm font-medium mb-1 ${isCurrentDay ? "text-primary" : ""}`}>
                          {format(day, "d")}
                        </div>
                        <div className="space-y-1">
                          {dayEvents.slice(0, 2).map((event) => (
                            <div
                              key={event.id}
                              className={`text-xs p-1 rounded truncate ${eventTypeColors[event.type]}`}
                              title={event.title}
                            >
                              {event.title}
                            </div>
                          ))}
                          {dayEvents.length > 2 && (
                            <div className="text-xs text-muted-foreground">
                              +{dayEvents.length - 2} المزيد
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Events */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>الأحداث القادمة</CardTitle>
              </CardHeader>
              <CardContent>
                {upcomingEvents && upcomingEvents.length > 0 ? (
                  <div className="space-y-3">
                    {upcomingEvents.map((event) => {
                      const subject = subjects?.find(s => s.id === event.subjectId);
                      return (
                        <div key={event.id} className={`p-3 rounded-lg border ${eventTypeColors[event.type]}`}>
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div className="flex-1">
                              <div className="font-medium">{event.title}</div>
                              <div className="text-xs mt-1">
                                {format(new Date(event.eventDate), "PPp", { locale: ar })}
                              </div>
                              {subject && (
                                <div className="text-xs mt-1">{subject.name}</div>
                              )}
                            </div>
                            <button
                              onClick={() => toggleComplete(event)}
                              className="shrink-0"
                            >
                              {event.completed ? (
                                <CheckCircle2 className="h-5 w-5 text-green-600" />
                              ) : (
                                <Circle className="h-5 w-5" />
                              )}
                            </button>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(event)}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(event.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    لا توجد أحداث قادمة
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
