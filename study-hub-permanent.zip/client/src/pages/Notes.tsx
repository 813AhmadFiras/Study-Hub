import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, FileText, Trash2, Edit, Pin, PinOff, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function Notes() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    subjectId: undefined as number | undefined,
    tags: [] as string[],
    isPinned: false,
  });

  const utils = trpc.useUtils();
  const { data: notes, isLoading } = trpc.notes.list.useQuery();
  const { data: subjects } = trpc.subjects.list.useQuery();
  
  const createMutation = trpc.notes.create.useMutation({
    onSuccess: () => {
      utils.notes.list.invalidate();
      setIsCreateOpen(false);
      resetForm();
      toast.success("تم إضافة الملاحظة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إضافة الملاحظة");
    },
  });

  const updateMutation = trpc.notes.update.useMutation({
    onSuccess: () => {
      utils.notes.list.invalidate();
      setEditingNote(null);
      resetForm();
      toast.success("تم تحديث الملاحظة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء تحديث الملاحظة");
    },
  });

  const deleteMutation = trpc.notes.delete.useMutation({
    onSuccess: () => {
      utils.notes.list.invalidate();
      toast.success("تم حذف الملاحظة بنجاح");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء حذف الملاحظة");
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      subjectId: undefined,
      tags: [],
      isPinned: false,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingNote) {
      updateMutation.mutate({ id: editingNote.id, ...formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (note: any) => {
    setEditingNote(note);
    setFormData({
      title: note.title,
      content: note.content,
      subjectId: note.subjectId,
      tags: note.tags || [],
      isPinned: note.isPinned,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الملاحظة؟")) {
      deleteMutation.mutate({ id });
    }
  };

  const togglePin = (note: any) => {
    updateMutation.mutate({
      id: note.id,
      isPinned: !note.isPinned,
    });
  };

  const filteredNotes = notes?.filter(note => 
    note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    note.content.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold">الملاحظات</h1>
            <p className="text-muted-foreground mt-1">دون أفكارك وملاحظاتك الدراسية</p>
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث في الملاحظات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
            <Dialog open={isCreateOpen || !!editingNote} onOpenChange={(open) => {
              if (!open) {
                setIsCreateOpen(false);
                setEditingNote(null);
                resetForm();
              } else {
                setIsCreateOpen(true);
              }
            }}>
              <DialogTrigger asChild>
                <Button className="gap-2 shrink-0">
                  <Plus className="h-4 w-4" />
                  إضافة ملاحظة
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <form onSubmit={handleSubmit}>
                  <DialogHeader>
                    <DialogTitle>{editingNote ? "تعديل الملاحظة" : "إضافة ملاحظة جديدة"}</DialogTitle>
                    <DialogDescription>
                      {editingNote ? "قم بتعديل محتوى الملاحظة" : "أضف ملاحظة جديدة لتنظيم أفكارك"}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">العنوان *</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="عنوان الملاحظة..."
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="content">المحتوى *</Label>
                      <Textarea
                        id="content"
                        value={formData.content}
                        onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                        placeholder="اكتب ملاحظتك هنا..."
                        rows={8}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject">المادة</Label>
                      <Select
                        value={formData.subjectId?.toString() || "none"}
                        onValueChange={(value) => setFormData({ ...formData, subjectId: value === "none" ? undefined : parseInt(value) })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر مادة (اختياري)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">بدون مادة</SelectItem>
                          {subjects?.map((subject) => (
                            <SelectItem key={subject.id} value={subject.id.toString()}>
                              {subject.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsCreateOpen(false);
                        setEditingNote(null);
                        resetForm();
                      }}
                    >
                      إلغاء
                    </Button>
                    <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                      {editingNote ? "تحديث" : "إضافة"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Notes Grid */}
        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-3/4" />
                  <div className="h-4 bg-muted rounded w-full mt-2" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : filteredNotes.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredNotes.map((note) => {
              const subject = subjects?.find(s => s.id === note.subjectId);
              return (
                <Card key={note.id} className="hover:shadow-lg transition-shadow flex flex-col">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          {note.isPinned && (
                            <Pin className="h-4 w-4 text-primary shrink-0" />
                          )}
                          <CardTitle className="text-lg truncate">{note.title}</CardTitle>
                        </div>
                        <CardDescription className="line-clamp-3">
                          {note.content}
                        </CardDescription>
                        {subject && (
                          <div className="mt-2">
                            <span
                              className="text-xs px-2 py-1 rounded-full text-white"
                              style={{ backgroundColor: subject.color || "#3b82f6" }}
                            >
                              {subject.name}
                            </span>
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground mt-2">
                          {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true, locale: ar })}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="mt-auto">
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => togglePin(note)}
                      >
                        {note.isPinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 gap-2"
                        onClick={() => handleEdit(note)}
                      >
                        <Edit className="h-4 w-4" />
                        تعديل
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDelete(note.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">
                {searchQuery ? "لا توجد نتائج" : "لا توجد ملاحظات"}
              </h3>
              <p className="text-muted-foreground text-center mb-4">
                {searchQuery ? "جرب البحث بكلمات أخرى" : "ابدأ بإضافة ملاحظة جديدة لتنظيم أفكارك"}
              </p>
              {!searchQuery && (
                <Button onClick={() => setIsCreateOpen(true)} className="gap-2">
                  <Plus className="h-4 w-4" />
                  إضافة ملاحظة
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
