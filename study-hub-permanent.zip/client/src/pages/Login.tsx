import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Eye, EyeOff, Mail, Lock, Github, Chrome } from "lucide-react";
import { useState } from "react";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // إعادة التوجيه إذا كان المستخدم مسجل دخول بالفعل
  if (isAuthenticated) {
    setLocation("/");
    return null;
  }

  const handleGoogleLogin = () => {
    window.location.href = getLoginUrl();
  };

  const handleGithubLogin = () => {
    // يمكن إضافة OAuth للـ GitHub لاحقاً
    window.location.href = getLoginUrl();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
      {/* Background decorative elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl -z-10"></div>

      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">📚</span>
            </div>
            <h1 className="text-2xl font-bold text-white">StudyHub</h1>
          </div>
          <p className="text-slate-400 text-sm">مركز الدراسة الشامل لتنظيم دراستك وتحسين إنتاجيتك</p>
        </div>

        {/* Main Card */}
        <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
          <CardHeader className="space-y-2 pb-6">
            <CardTitle className="text-white text-2xl">أهلاً بعودتك</CardTitle>
            <CardDescription className="text-slate-400">
              سجل دخولك إلى حسابك في StudyHub
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Email Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <Input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 pl-10 focus:border-blue-500 focus:ring-blue-500/20"
                />
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="أدخل كلمة المرور"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-500 pl-10 pr-10 focus:border-blue-500 focus:ring-blue-500/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {/* Forgot Password Link */}
            <div className="text-right">
              <a href="#" className="text-sm text-blue-400 hover:text-blue-300 transition-colors">
                هل نسيت كلمة المرور؟
              </a>
            </div>

            {/* Sign In Button */}
            <Button
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-2 rounded-lg transition-all duration-200"
              size="lg"
            >
              تسجيل الدخول
            </Button>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-600"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-slate-800/50 text-slate-400">أو تابع مع</span>
              </div>
            </div>

            {/* Social Login Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={handleGoogleLogin}
                className="bg-slate-700/50 border-slate-600 hover:bg-slate-700 text-white transition-colors"
              >
                <Chrome className="w-4 h-4 ml-2" />
                Google
              </Button>
              <Button
                variant="outline"
                onClick={handleGithubLogin}
                className="bg-slate-700/50 border-slate-600 hover:bg-slate-700 text-white transition-colors"
              >
                <Github className="w-4 h-4 ml-2" />
                GitHub
              </Button>
            </div>

            {/* Sign Up Link */}
            <p className="text-center text-slate-400 text-sm">
              ليس لديك حساب؟{" "}
              <a href="#" className="text-blue-400 hover:text-blue-300 font-semibold transition-colors">
                إنشاء حساب جديد
              </a>
            </p>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center text-xs text-slate-500">
          <p>بالمتابعة، فإنك توافق على شروط الخدمة وسياسة الخصوصية</p>
        </div>
      </div>
    </div>
  );
}
