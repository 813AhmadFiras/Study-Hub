import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { useAuth } from "@/_core/hooks/useAuth";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import EnhancedDashboard from "./pages/EnhancedDashboard";
import Search from "./pages/Search";
import VoiceRecorder from "./pages/VoiceRecorder";
import Subjects from "./pages/Subjects";
import Notes from "./pages/Notes";
import Flashcards from "./pages/Flashcards";
import Pomodoro from "./pages/Pomodoro";
import Calendar from "./pages/Calendar";
import Solver from "./pages/Solver";
import { EnhancedAIChat } from "./pages/AIChat/EnhancedAIChat";
import Files from "./pages/Files";
import Notifications from "./pages/Notifications";
import Settings from "./pages/Settings";
import SetupGuidePage from "./pages/SetupGuidePage";
import Login from "./pages/Login";
import LandingPage from "./pages/LandingPage";
import { OnboardingPage } from "./pages/Onboarding/OnboardingPage";
import FloatingChat from "./components/FloatingChat";

function Router() {
  // Check if user is authenticated
  const { isAuthenticated } = useAuth();
  const onboardingComplete = localStorage.getItem("onboarding") !== null;

  return (
    <Switch>
      <Route path="/onboarding" component={OnboardingPage} />
      <Route path="/dashboard" component={EnhancedDashboard} />
      <Route path="/" component={isAuthenticated ? (onboardingComplete ? EnhancedDashboard : OnboardingPage) : LandingPage} />
      <Route path="/search" component={Search} />
      <Route path="/recorder" component={VoiceRecorder} />
      <Route path="/subjects" component={Subjects} />
      <Route path="/notes" component={Notes} />
      <Route path="/flashcards" component={Flashcards} />
      <Route path="/pomodoro" component={Pomodoro} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/solver" component={Solver} />
      <Route path="/chat" component={EnhancedAIChat} />
      <Route path="/files" component={Files} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/settings" component={Settings} />
      <Route path="/setup" component={SetupGuidePage} />
      <Route path="/login" component={Login} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="system">
        <TooltipProvider>
          <Toaster position="top-center" richColors />
          <Router />
          <FloatingChat />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
